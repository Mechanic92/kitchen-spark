import { useState } from 'react'
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { Clock, Users, Heart, ChefHat, Play, BookOpen, Lightbulb, Star } from 'lucide-react'

export function RecipeDetailModal({ recipe, isOpen, onClose, onSave, isSaved }) {
  const [activeTab, setActiveTab] = useState('ingredients')

  if (!recipe) return null

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="text-2xl font-bold text-gray-900 dark:text-white">
            {recipe.title}
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-6">
          {/* Hero Image and Basic Info */}
          <div className="relative">
            <img 
              src={recipe.image} 
              alt={recipe.title}
              className="w-full h-64 object-cover rounded-lg"
            />
            <div className="absolute top-4 right-4">
              <Button
                variant="ghost"
                size="sm"
                onClick={() => onSave(recipe)}
                className="bg-white/80 backdrop-blur-sm hover:bg-white/90 text-red-500 hover:text-red-600 rounded-full p-2"
              >
                <Heart className={`h-5 w-5 ${isSaved ? 'fill-current' : ''}`} />            </Button>
            </div>
            <div className="absolute bottom-4 left-4">
              <Badge variant="secondary" className="bg-black/70 text-white backdrop-blur-sm">
                <ChefHat className="h-3 w-3 mr-1" />
                {recipe.difficulty}
              </Badge>
            </div>
          </div>

          {/* Quick Stats */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <div className="text-center p-3 bg-gray-50 dark:bg-gray-800 rounded-lg">
              <Clock className="h-5 w-5 mx-auto mb-1 text-blue-600" />
              <p className="text-sm font-medium">{recipe.cookTime}</p>
              <p className="text-xs text-gray-600 dark:text-gray-300">Cook Time</p>
            </div>
            <div className="text-center p-3 bg-gray-50 dark:bg-gray-800 rounded-lg">
              <Users className="h-5 w-5 mx-auto mb-1 text-green-600" />
              <p className="text-sm font-medium">{recipe.servings}</p>
              <p className="text-xs text-gray-600 dark:text-gray-300">Servings</p>
            </div>
            <div className="text-center p-3 bg-gray-50 dark:bg-gray-800 rounded-lg">
              <Star className="h-5 w-5 mx-auto mb-1 text-yellow-600" />
              <p className="text-sm font-medium">{recipe.calories}</p>
              <p className="text-xs text-gray-600 dark:text-gray-300">Calories</p>
            </div>
            <div className="text-center p-3 bg-gray-50 dark:bg-gray-800 rounded-lg">
              <ChefHat className="h-5 w-5 mx-auto mb-1 text-purple-600" />
              <p className="text-sm font-medium">{recipe.category || 'Delicious'}</p>
              <p className="text-xs text-gray-600 dark:text-gray-300">Category</p>
            </div>
          </div>

          {/* Description */}
          <div>
            <p className="text-gray-700 dark:text-gray-300 leading-relaxed">
              {recipe.description}
            </p>
          </div>

          {/* Tags */}
          <div className="flex flex-wrap gap-2">
            {recipe.tags.map((tag, index) => (
              <Badge key={index} variant="outline" className="text-xs">
                {tag}
              </Badge>
            ))}
          </div>

          {/* Tabbed Content */}
          <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
            <TabsList className="grid w-full grid-cols-4">
              <TabsTrigger value="ingredients" className="flex items-center gap-2">
                <BookOpen className="h-4 w-4" />
                Ingredients
              </TabsTrigger>
              <TabsTrigger value="instructions" className="flex items-center gap-2">
                <Play className="h-4 w-4" />
                Instructions
              </TabsTrigger>
              <TabsTrigger value="nutrition" className="flex items-center gap-2">
                <Star className="h-4 w-4" />
                Nutrition
              </TabsTrigger>
              <TabsTrigger value="tips" className="flex items-center gap-2">
                <Lightbulb className="h-4 w-4" />
                Tips
              </TabsTrigger>
            </TabsList>

            <TabsContent value="ingredients" className="mt-4">
              <div className="space-y-3">
                <h3 className="text-lg font-semibold">Ingredients</h3>
                <div className="grid gap-2">
                  {recipe.ingredients?.map((ingredient, index) => (
                    <div key={index} className="flex items-center p-2 bg-gray-50 dark:bg-gray-800 rounded-lg">
                      <div className="w-6 h-6 bg-blue-100 dark:bg-blue-900 rounded-full flex items-center justify-center mr-3">
                        <span className="text-xs font-medium text-blue-600 dark:text-blue-300">
                          {index + 1}
                        </span>
                      </div>
                      <span className="text-sm">{ingredient}</span>
                    </div>
                  )) || (
                    <p className="text-gray-600 dark:text-gray-300">
                      Ingredients list will be available soon! Check back for detailed measurements and preparation notes.
                    </p>
                  )}
                </div>
              </div>
            </TabsContent>

            <TabsContent value="instructions" className="mt-4">
              <div className="space-y-3">
                <h3 className="text-lg font-semibold">Instructions</h3>
                <div className="space-y-4">
                  {recipe.instructions?.map((step, index) => (
                    <div key={index} className="flex gap-4">
                      <div className="flex-shrink-0 w-8 h-8 bg-gradient-to-r from-blue-600 to-purple-600 rounded-full flex items-center justify-center">
                        <span className="text-sm font-medium text-white">
                          {index + 1}
                        </span>
                      </div>
                      <div className="flex-1">
                        <p className="text-sm text-gray-700 dark:text-gray-300 leading-relaxed">
                          {step}
                        </p>
                      </div>
                    </div>
                  )) || (
                    <p className="text-gray-600 dark:text-gray-300">
                      Detailed cooking instructions coming soon! We're working on providing step-by-step guidance for the perfect result.
                    </p>
                  )}
                </div>
              </div>
            </TabsContent>

            <TabsContent value="nutrition" className="mt-4">
              <div className="space-y-3">
                <h3 className="text-lg font-semibold">Nutrition Information</h3>
                {recipe.nutrition ? (
                  <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                    {Object.entries(recipe.nutrition).map(([key, value]) => (
                      <div key={key} className="text-center p-3 bg-gray-50 dark:bg-gray-800 rounded-lg">
                        <p className="text-lg font-semibold text-gray-900 dark:text-white">
                          {value}
                        </p>
                        <p className="text-xs text-gray-600 dark:text-gray-300 capitalize">
                          {key}
                        </p>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="text-center p-6 bg-gray-50 dark:bg-gray-800 rounded-lg">
                    <Star className="h-8 w-8 mx-auto mb-2 text-gray-400" />
                    <p className="text-gray-600 dark:text-gray-300">
                      Nutrition information will be calculated and displayed here soon!
                    </p>
                  </div>
                )}
              </div>
            </TabsContent>

            <TabsContent value="tips" className="mt-4">
              <div className="space-y-3">
                <h3 className="text-lg font-semibold">Pro Tips</h3>
                <div className="space-y-3">
                  {recipe.tips?.map((tip, index) => (
                    <div key={index} className="flex gap-3 p-3 bg-yellow-50 dark:bg-yellow-900/20 rounded-lg border border-yellow-200 dark:border-yellow-800">
                      <Lightbulb className="h-5 w-5 text-yellow-600 dark:text-yellow-400 flex-shrink-0 mt-0.5" />
                      <p className="text-sm text-gray-700 dark:text-gray-300">
                        {tip}
                      </p>
                    </div>
                  )) || (
                    <div className="text-center p-6 bg-yellow-50 dark:bg-yellow-900/20 rounded-lg border border-yellow-200 dark:border-yellow-800">
                      <Lightbulb className="h-8 w-8 mx-auto mb-2 text-yellow-600 dark:text-yellow-400" />
                      <p className="text-gray-600 dark:text-gray-300">
                        Cooking tips and tricks will be added here to help you master this recipe!
                      </p>
                    </div>
                  )}
                </div>
              </div>
            </TabsContent>
          </Tabs>

          {/* YouTube Video Link */}
          {recipe.youtubeUrl && (
            <div className="border-t pt-4">
              <Button 
                variant="outline" 
                className="w-full"
                onClick={() => window.open(recipe.youtubeUrl, '_blank')}
              >
                <Play className="h-4 w-4 mr-2" />
                Watch Video Tutorial
              </Button>
            </div>
          )}

          {/* Action Buttons */}
          <div className="flex gap-3 pt-4 border-t">
            <Button 
              className="flex-1 bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700"
              onClick={() => {
                // In a real app, this would start cooking mode or add to meal plan
                alert('Added to your cooking queue! 👨‍🍳')
              }}
            >
              <ChefHat className="h-4 w-4 mr-2" />
              Start Cooking
            </Button>
            <Button 
              variant="outline"
              onClick={() => {
                // In a real app, this would add to shopping list
                alert('Ingredients added to shopping list! 🛒')
              }}
            >
              Add to Shopping List
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  )
}

