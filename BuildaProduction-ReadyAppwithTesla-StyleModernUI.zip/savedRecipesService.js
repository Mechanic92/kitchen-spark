import authService from './authService';

const API_BASE_URL = '/api';

class SavedRecipesService {
  // Save a recipe to user's collection
  async saveRecipe(recipeData) {
    try {
      if (!authService.isAuthenticated()) {
        throw new Error('Authentication required');
      }

      const response = await fetch(`${API_BASE_URL}/recipes/save`, {
        method: 'POST',
        headers: authService.getAuthHeaders(),
        body: JSON.stringify(recipeData)
      });

      const data = await response.json();

      if (!response.ok) {
        throw new Error(data.error || 'Failed to save recipe');
      }

      return { success: true, recipe: data.recipe };
    } catch (error) {
      console.error('Save recipe error:', error);
      return { success: false, error: error.message };
    }
  }

  // Get user's saved recipes
  async getSavedRecipes(options = {}) {
    try {
      if (!authService.isAuthenticated()) {
        throw new Error('Authentication required');
      }

      const params = new URLSearchParams();
      if (options.page) params.append('page', options.page);
      if (options.per_page) params.append('per_page', options.per_page);
      if (options.search) params.append('search', options.search);
      if (options.source) params.append('source', options.source);

      const url = `${API_BASE_URL}/recipes/saved${params.toString() ? '?' + params.toString() : ''}`;

      const response = await fetch(url, {
        method: 'GET',
        headers: authService.getAuthHeaders()
      });

      const data = await response.json();

      if (!response.ok) {
        throw new Error(data.error || 'Failed to get saved recipes');
      }

      return { 
        success: true, 
        recipes: data.recipes,
        pagination: data.pagination,
        subscriptionInfo: data.subscription_info
      };
    } catch (error) {
      console.error('Get saved recipes error:', error);
      return { success: false, error: error.message };
    }
  }

  // Remove a recipe from saved collection
  async removeSavedRecipe(recipeDbId) {
    try {
      if (!authService.isAuthenticated()) {
        throw new Error('Authentication required');
      }

      const response = await fetch(`${API_BASE_URL}/recipes/saved/${recipeDbId}`, {
        method: 'DELETE',
        headers: authService.getAuthHeaders()
      });

      const data = await response.json();

      if (!response.ok) {
        throw new Error(data.error || 'Failed to remove recipe');
      }

      return { success: true, message: data.message };
    } catch (error) {
      console.error('Remove saved recipe error:', error);
      return { success: false, error: error.message };
    }
  }

  // Update notes for a saved recipe
  async updateRecipeNotes(recipeDbId, notes) {
    try {
      if (!authService.isAuthenticated()) {
        throw new Error('Authentication required');
      }

      const response = await fetch(`${API_BASE_URL}/recipes/saved/${recipeDbId}/notes`, {
        method: 'PUT',
        headers: authService.getAuthHeaders(),
        body: JSON.stringify({ notes })
      });

      const data = await response.json();

      if (!response.ok) {
        throw new Error(data.error || 'Failed to update notes');
      }

      return { success: true, recipe: data.recipe };
    } catch (error) {
      console.error('Update recipe notes error:', error);
      return { success: false, error: error.message };
    }
  }

  // Update rating for a saved recipe
  async updateRecipeRating(recipeDbId, rating) {
    try {
      if (!authService.isAuthenticated()) {
        throw new Error('Authentication required');
      }

      const response = await fetch(`${API_BASE_URL}/recipes/saved/${recipeDbId}/rating`, {
        method: 'PUT',
        headers: authService.getAuthHeaders(),
        body: JSON.stringify({ rating })
      });

      const data = await response.json();

      if (!response.ok) {
        throw new Error(data.error || 'Failed to update rating');
      }

      return { success: true, recipe: data.recipe };
    } catch (error) {
      console.error('Update recipe rating error:', error);
      return { success: false, error: error.message };
    }
  }

  // Check if a recipe is saved
  async checkRecipeSaved(recipeId, source = 'themealdb') {
    try {
      if (!authService.isAuthenticated()) {
        return { success: true, is_saved: false };
      }

      const params = new URLSearchParams({ source });
      const response = await fetch(`${API_BASE_URL}/recipes/check-saved/${recipeId}?${params.toString()}`, {
        method: 'GET',
        headers: authService.getAuthHeaders()
      });

      const data = await response.json();

      if (!response.ok) {
        throw new Error(data.error || 'Failed to check recipe status');
      }

      return { 
        success: true, 
        is_saved: data.is_saved,
        saved_recipe: data.saved_recipe
      };
    } catch (error) {
      console.error('Check recipe saved error:', error);
      return { success: false, error: error.message };
    }
  }

  // Get subscription limits
  async getSubscriptionLimits() {
    try {
      if (!authService.isAuthenticated()) {
        throw new Error('Authentication required');
      }

      const response = await fetch(`${API_BASE_URL}/recipes/subscription-limits`, {
        method: 'GET',
        headers: authService.getAuthHeaders()
      });

      const data = await response.json();

      if (!response.ok) {
        throw new Error(data.error || 'Failed to get subscription limits');
      }

      return { 
        success: true, 
        tier: data.tier,
        limits: data.limits,
        usage: data.usage,
        canSaveMore: data.can_save_more
      };
    } catch (error) {
      console.error('Get subscription limits error:', error);
      return { success: false, error: error.message };
    }
  }

  // Discover recipes (public endpoint)
  async discoverRecipes(options = {}) {
    try {
      const params = new URLSearchParams();
      if (options.category) params.append('category', options.category);
      if (options.area) params.append('area', options.area);
      if (options.search) params.append('search', options.search);

      const url = `${API_BASE_URL}/recipes/discover${params.toString() ? '?' + params.toString() : ''}`;

      const response = await fetch(url, {
        method: 'GET',
        headers: {
          'Content-Type': 'application/json'
        }
      });

      const data = await response.json();

      if (!response.ok) {
        throw new Error(data.error || 'Failed to discover recipes');
      }

      return { 
        success: true, 
        recipes: data.recipes,
        total: data.total
      };
    } catch (error) {
      console.error('Discover recipes error:', error);
      return { success: false, error: error.message };
    }
  }
}

// Create singleton instance
const savedRecipesService = new SavedRecipesService();

export default savedRecipesService;

