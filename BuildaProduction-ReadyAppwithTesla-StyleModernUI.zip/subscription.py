from flask import Blueprint, request, jsonify, current_app
from flask_jwt_extended import jwt_required, get_jwt_identity
import stripe
import os
from datetime import datetime
from src.models.user import db, User, Subscription, PaymentHistory, UserActivity

subscription_bp = Blueprint('subscription', __name__)

# Initialize Stripe
stripe.api_key = os.getenv('STRIPE_SECRET_KEY', 'sk_test_your_stripe_secret_key_here')

# Subscription tiers and pricing
SUBSCRIPTION_TIERS = {
    'premium': {
        'name': 'Premium',
        'price': 999,  # $9.99 in cents
        'currency': 'usd',
        'interval': 'month',
        'features': [
            'Unlimited recipe saves',
            'Advanced search and filtering',
            'Unlimited AI chat interactions',
            'Meal planning tools',
            'Shopping list generation',
            'Email support'
        ],
        'stripe_price_id': 'price_premium_monthly'  # Replace with actual Stripe price ID
    },
    'pro': {
        'name': 'Pro',
        'price': 1999,  # $19.99 in cents
        'currency': 'usd',
        'interval': 'month',
        'features': [
            'All Premium features',
            'Recipe creation and sharing',
            'Advanced nutritional analysis',
            'Batch cooking calculators',
            'Smart kitchen device integration',
            'Priority customer support',
            'Export recipes to PDF',
            'Custom meal plans'
        ],
        'stripe_price_id': 'price_pro_monthly'  # Replace with actual Stripe price ID
    }
}

@subscription_bp.route('/tiers', methods=['GET'])
def get_subscription_tiers():
    """Get available subscription tiers and pricing"""
    try:
        # Add free tier information
        tiers = {
            'free': {
                'name': 'Free',
                'price': 0,
                'currency': 'usd',
                'interval': 'month',
                'features': [
                    'Basic recipe discovery',
                    'Save up to 10 recipes',
                    'Limited AI chat (5 queries/day)',
                    'Basic search functionality'
                ]
            }
        }
        
        # Add paid tiers
        tiers.update(SUBSCRIPTION_TIERS)
        
        return jsonify({
            'tiers': tiers
        }), 200
        
    except Exception as e:
        current_app.logger.error(f"Get subscription tiers error: {str(e)}")
        return jsonify({'error': 'Failed to get subscription tiers'}), 500

@subscription_bp.route('/create-checkout', methods=['POST'])
@jwt_required()
def create_checkout_session():
    """Create Stripe checkout session for subscription"""
    try:
        user_id = get_jwt_identity()
        user = User.query.get(user_id)
        
        if not user:
            return jsonify({'error': 'User not found'}), 404
        
        data = request.get_json()
        tier = data.get('tier')
        
        if tier not in SUBSCRIPTION_TIERS:
            return jsonify({'error': 'Invalid subscription tier'}), 400
        
        tier_info = SUBSCRIPTION_TIERS[tier]
        
        # Create or get Stripe customer
        if not user.stripe_customer_id:
            customer = stripe.Customer.create(
                email=user.email,
                name=f"{user.first_name} {user.last_name}".strip(),
                metadata={
                    'user_id': user.id
                }
            )
            user.stripe_customer_id = customer.id
            db.session.commit()
        
        # Create checkout session
        checkout_session = stripe.checkout.Session.create(
            customer=user.stripe_customer_id,
            payment_method_types=['card'],
            line_items=[{
                'price_data': {
                    'currency': tier_info['currency'],
                    'product_data': {
                        'name': f"Kitchen Spark {tier_info['name']}",
                        'description': f"Monthly subscription to Kitchen Spark {tier_info['name']} tier"
                    },
                    'unit_amount': tier_info['price'],
                    'recurring': {
                        'interval': tier_info['interval']
                    }
                },
                'quantity': 1,
            }],
            mode='subscription',
            success_url=request.host_url + 'subscription/success?session_id={CHECKOUT_SESSION_ID}',
            cancel_url=request.host_url + 'subscription/cancel',
            metadata={
                'user_id': user.id,
                'tier': tier
            }
        )
        
        # Log activity
        activity = UserActivity(
            user_id=user_id,
            activity_type='checkout_session_created',
            metadata=f'{{"tier": "{tier}", "session_id": "{checkout_session.id}"}}'
        )
        db.session.add(activity)
        db.session.commit()
        
        return jsonify({
            'checkout_url': checkout_session.url,
            'session_id': checkout_session.id
        }), 200
        
    except stripe.error.StripeError as e:
        current_app.logger.error(f"Stripe error: {str(e)}")
        return jsonify({'error': 'Payment processing error'}), 500
    except Exception as e:
        current_app.logger.error(f"Create checkout error: {str(e)}")
        return jsonify({'error': 'Failed to create checkout session'}), 500

@subscription_bp.route('/webhook', methods=['POST'])
def stripe_webhook():
    """Handle Stripe webhook events"""
    try:
        payload = request.get_data()
        sig_header = request.headers.get('Stripe-Signature')
        webhook_secret = os.getenv('STRIPE_WEBHOOK_SECRET')
        
        if not webhook_secret:
            current_app.logger.error("Stripe webhook secret not configured")
            return jsonify({'error': 'Webhook not configured'}), 400
        
        # Verify webhook signature
        try:
            event = stripe.Webhook.construct_event(
                payload, sig_header, webhook_secret
            )
        except ValueError:
            current_app.logger.error("Invalid payload in webhook")
            return jsonify({'error': 'Invalid payload'}), 400
        except stripe.error.SignatureVerificationError:
            current_app.logger.error("Invalid signature in webhook")
            return jsonify({'error': 'Invalid signature'}), 400
        
        # Handle the event
        if event['type'] == 'checkout.session.completed':
            session = event['data']['object']
            handle_successful_payment(session)
            
        elif event['type'] == 'invoice.payment_succeeded':
            invoice = event['data']['object']
            handle_successful_subscription_payment(invoice)
            
        elif event['type'] == 'invoice.payment_failed':
            invoice = event['data']['object']
            handle_failed_payment(invoice)
            
        elif event['type'] == 'customer.subscription.updated':
            subscription = event['data']['object']
            handle_subscription_updated(subscription)
            
        elif event['type'] == 'customer.subscription.deleted':
            subscription = event['data']['object']
            handle_subscription_cancelled(subscription)
        
        return jsonify({'status': 'success'}), 200
        
    except Exception as e:
        current_app.logger.error(f"Webhook error: {str(e)}")
        return jsonify({'error': 'Webhook processing failed'}), 500

def handle_successful_payment(session):
    """Handle successful checkout session completion"""
    try:
        user_id = session['metadata'].get('user_id')
        tier = session['metadata'].get('tier')
        
        if not user_id or not tier:
            current_app.logger.error("Missing metadata in checkout session")
            return
        
        user = User.query.get(int(user_id))
        if not user:
            current_app.logger.error(f"User not found: {user_id}")
            return
        
        # Update user subscription tier
        user.subscription_tier = tier
        user.updated_at = datetime.utcnow()
        
        # Create subscription record
        subscription = Subscription(
            user_id=user.id,
            stripe_subscription_id=session.get('subscription'),
            tier=tier,
            status='active',
            current_period_start=datetime.utcnow(),
            current_period_end=datetime.utcnow()  # Will be updated by subscription webhook
        )
        
        db.session.add(subscription)
        
        # Create payment history record
        payment = PaymentHistory(
            user_id=user.id,
            stripe_payment_intent_id=session.get('payment_intent'),
            amount=session.get('amount_total', 0),
            currency=session.get('currency', 'usd'),
            status='succeeded',
            description=f"Subscription to {tier} tier"
        )
        
        db.session.add(payment)
        
        # Log activity
        activity = UserActivity(
            user_id=user.id,
            activity_type='subscription_activated',
            metadata=f'{{"tier": "{tier}", "session_id": "{session["id"]}"}}'
        )
        db.session.add(activity)
        
        db.session.commit()
        
        current_app.logger.info(f"Successfully activated {tier} subscription for user {user_id}")
        
    except Exception as e:
        db.session.rollback()
        current_app.logger.error(f"Error handling successful payment: {str(e)}")

def handle_successful_subscription_payment(invoice):
    """Handle successful recurring subscription payment"""
    try:
        customer_id = invoice['customer']
        subscription_id = invoice['subscription']
        
        # Find user by Stripe customer ID
        user = User.query.filter_by(stripe_customer_id=customer_id).first()
        if not user:
            current_app.logger.error(f"User not found for customer: {customer_id}")
            return
        
        # Update subscription record
        subscription = Subscription.query.filter_by(
            stripe_subscription_id=subscription_id
        ).first()
        
        if subscription:
            subscription.status = 'active'
            subscription.current_period_start = datetime.fromtimestamp(invoice['period_start'])
            subscription.current_period_end = datetime.fromtimestamp(invoice['period_end'])
            subscription.updated_at = datetime.utcnow()
        
        # Create payment history record
        payment = PaymentHistory(
            user_id=user.id,
            stripe_payment_intent_id=invoice.get('payment_intent'),
            amount=invoice.get('amount_paid', 0),
            currency=invoice.get('currency', 'usd'),
            status='succeeded',
            description=f"Recurring payment for {user.subscription_tier} tier"
        )
        
        db.session.add(payment)
        
        # Log activity
        activity = UserActivity(
            user_id=user.id,
            activity_type='subscription_payment_succeeded',
            metadata=f'{{"amount": {invoice.get("amount_paid", 0)}, "invoice_id": "{invoice["id"]}"}}'
        )
        db.session.add(activity)
        
        db.session.commit()
        
    except Exception as e:
        db.session.rollback()
        current_app.logger.error(f"Error handling successful subscription payment: {str(e)}")

def handle_failed_payment(invoice):
    """Handle failed subscription payment"""
    try:
        customer_id = invoice['customer']
        
        # Find user by Stripe customer ID
        user = User.query.filter_by(stripe_customer_id=customer_id).first()
        if not user:
            current_app.logger.error(f"User not found for customer: {customer_id}")
            return
        
        # Create payment history record
        payment = PaymentHistory(
            user_id=user.id,
            stripe_payment_intent_id=invoice.get('payment_intent'),
            amount=invoice.get('amount_due', 0),
            currency=invoice.get('currency', 'usd'),
            status='failed',
            description=f"Failed payment for {user.subscription_tier} tier"
        )
        
        db.session.add(payment)
        
        # Log activity
        activity = UserActivity(
            user_id=user.id,
            activity_type='subscription_payment_failed',
            metadata=f'{{"amount": {invoice.get("amount_due", 0)}, "invoice_id": "{invoice["id"]}"}}'
        )
        db.session.add(activity)
        
        db.session.commit()
        
    except Exception as e:
        db.session.rollback()
        current_app.logger.error(f"Error handling failed payment: {str(e)}")

def handle_subscription_updated(stripe_subscription):
    """Handle subscription updates"""
    try:
        subscription = Subscription.query.filter_by(
            stripe_subscription_id=stripe_subscription['id']
        ).first()
        
        if subscription:
            subscription.status = stripe_subscription['status']
            subscription.current_period_start = datetime.fromtimestamp(stripe_subscription['current_period_start'])
            subscription.current_period_end = datetime.fromtimestamp(stripe_subscription['current_period_end'])
            subscription.updated_at = datetime.utcnow()
            
            db.session.commit()
        
    except Exception as e:
        db.session.rollback()
        current_app.logger.error(f"Error handling subscription update: {str(e)}")

def handle_subscription_cancelled(stripe_subscription):
    """Handle subscription cancellation"""
    try:
        subscription = Subscription.query.filter_by(
            stripe_subscription_id=stripe_subscription['id']
        ).first()
        
        if subscription:
            subscription.status = 'cancelled'
            subscription.updated_at = datetime.utcnow()
            
            # Downgrade user to free tier
            user = User.query.get(subscription.user_id)
            if user:
                user.subscription_tier = 'free'
                user.updated_at = datetime.utcnow()
                
                # Log activity
                activity = UserActivity(
                    user_id=user.id,
                    activity_type='subscription_cancelled',
                    metadata=f'{{"previous_tier": "{subscription.tier}"}}'
                )
                db.session.add(activity)
            
            db.session.commit()
        
    except Exception as e:
        db.session.rollback()
        current_app.logger.error(f"Error handling subscription cancellation: {str(e)}")

@subscription_bp.route('/status', methods=['GET'])
@jwt_required()
def get_subscription_status():
    """Get current user's subscription status"""
    try:
        user_id = get_jwt_identity()
        user = User.query.get(user_id)
        
        if not user:
            return jsonify({'error': 'User not found'}), 404
        
        # Get active subscription
        subscription = Subscription.query.filter_by(
            user_id=user_id,
            status='active'
        ).order_by(Subscription.created_at.desc()).first()
        
        # Get recent payments
        payments = PaymentHistory.query.filter_by(
            user_id=user_id
        ).order_by(PaymentHistory.created_at.desc()).limit(5).all()
        
        return jsonify({
            'tier': user.subscription_tier,
            'subscription': subscription.to_dict() if subscription else None,
            'recent_payments': [payment.to_dict() for payment in payments]
        }), 200
        
    except Exception as e:
        current_app.logger.error(f"Get subscription status error: {str(e)}")
        return jsonify({'error': 'Failed to get subscription status'}), 500

@subscription_bp.route('/cancel', methods=['POST'])
@jwt_required()
def cancel_subscription():
    """Cancel user's subscription"""
    try:
        user_id = get_jwt_identity()
        user = User.query.get(user_id)
        
        if not user:
            return jsonify({'error': 'User not found'}), 404
        
        # Find active subscription
        subscription = Subscription.query.filter_by(
            user_id=user_id,
            status='active'
        ).first()
        
        if not subscription or not subscription.stripe_subscription_id:
            return jsonify({'error': 'No active subscription found'}), 404
        
        # Cancel subscription in Stripe
        stripe.Subscription.delete(subscription.stripe_subscription_id)
        
        # Update local records (webhook will handle the rest)
        subscription.status = 'cancelled'
        subscription.updated_at = datetime.utcnow()
        
        user.subscription_tier = 'free'
        user.updated_at = datetime.utcnow()
        
        # Log activity
        activity = UserActivity(
            user_id=user_id,
            activity_type='subscription_cancelled_by_user',
            metadata=f'{{"tier": "{subscription.tier}"}}'
        )
        db.session.add(activity)
        
        db.session.commit()
        
        return jsonify({
            'message': 'Subscription cancelled successfully'
        }), 200
        
    except stripe.error.StripeError as e:
        current_app.logger.error(f"Stripe error cancelling subscription: {str(e)}")
        return jsonify({'error': 'Failed to cancel subscription'}), 500
    except Exception as e:
        db.session.rollback()
        current_app.logger.error(f"Cancel subscription error: {str(e)}")
        return jsonify({'error': 'Failed to cancel subscription'}), 500

