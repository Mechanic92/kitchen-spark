import { useState, useRef, useEffect } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Badge } from '@/components/ui/badge'
import { Send, Bot, User, Sparkles, ChefHat } from 'lucide-react'

import authService from '../services/authService';

export function AIChat({ onRecipeGenerated }) {
  const [currentUser, setCurrentUser] = useState(authService.getCurrentUser());

  useEffect(() => {
    const checkAuth = async () => {
      const result = await authService.verifyToken();
      if (result.success) {
        setCurrentUser(result.user);
      } else {
        setCurrentUser(null);
      }
    };
    checkAuth();
  }, []);
  const [messages, setMessages] = useState([
    {
      id: 1,
      type: 'ai',
      content: "Hey there, future chef! 👋 I'm your AI cooking buddy. Tell me what's in your fridge, your mood, or just say 'surprise me' and I'll whip up something amazing!",
      timestamp: new Date()
    }
  ])
  const [inputValue, setInputValue] = useState('')
  const [isTyping, setIsTyping] = useState(false)
  const messagesEndRef = useRef(null)

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" })
  }

  useEffect(() => {
    scrollToBottom()
  }, [messages])

  const quickPrompts = [
    "What can I make with eggs?",
    "Healthy dinner ideas",
    "Quick 15-min meals",
    "Comfort food recipes",
    "Surprise me!"
  ]

  const handleSendMessage = async (message = inputValue) => {
    if (!message.trim()) return

    const userMessage = {
      id: Date.now(),
      type: 'user',
      content: message,
      timestamp: new Date()
    }

    setMessages(prev => [...prev, userMessage])
    setInputValue('')
    setIsTyping(true)

    // Simulate AI response
    setTimeout(() => {
      const aiResponse = generateAIResponse(message)
      setMessages(prev => [...prev, aiResponse])
      setIsTyping(false)
    }, 1500)
  }

  const generateAIResponse = (userMessage) => {
    const responses = {
      "eggs": {
        content: "Eggs are like the Swiss Army knife of cooking! 🥚 Here are some egg-cellent ideas: Fluffy scrambled eggs with herbs, a classic omelet with whatever veggies you have, or how about shakshuka for something exotic? Want me to generate a specific recipe?",
        recipe: {
          title: "Perfect Fluffy Scrambled Eggs",
          cookTime: "5 mins",
          difficulty: "Easy",
          ingredients: ["3 eggs", "2 tbsp butter", "Salt & pepper", "Fresh chives"]
        }
      },
      "healthy": {
        content: "Time to fuel your body like the temple it is! 💪 I'm thinking colorful Buddha bowls, zesty quinoa salads, or maybe some grilled salmon with roasted veggies? What's your vibe - Mediterranean, Asian fusion, or keep it simple?",
        recipe: {
          title: "Rainbow Buddha Bowl",
          cookTime: "20 mins",
          difficulty: "Easy",
          ingredients: ["Quinoa", "Roasted chickpeas", "Avocado", "Purple cabbage", "Tahini dressing"]
        }
      },
      "quick": {
        content: "Speed cooking mode activated! ⚡ How about a killer pasta aglio e olio (just garlic, olive oil, and pasta - but make it fancy), or a loaded quesadilla that'll blow your mind? Quick doesn't mean boring!",
        recipe: {
          title: "Lightning Pasta Aglio e Olio",
          cookTime: "12 mins",
          difficulty: "Easy",
          ingredients: ["Spaghetti", "Garlic", "Olive oil", "Red pepper flakes", "Parmesan"]
        }
      },
      "comfort": {
        content: "Ah, comfort food - the warm hug your soul needs! 🤗 I'm talking creamy mac and cheese, hearty chicken soup, or maybe some loaded grilled cheese with tomato soup for dipping? What kind of comfort are we talking?",
        recipe: {
          title: "Ultimate Grilled Cheese",
          cookTime: "8 mins",
          difficulty: "Easy",
          ingredients: ["Sourdough bread", "Aged cheddar", "Gruyere", "Butter", "Dijon mustard"]
        }
      },
      "surprise": {
        content: "Plot twist time! 🎲 How about Korean-style corn dogs (trust me on this), or maybe some fusion tacos with unexpected fillings? I'm feeling adventurous - are you ready to step outside your comfort zone?",
        recipe: {
          title: "Korean Corn Dogs",
          cookTime: "25 mins",
          difficulty: "Medium",
          ingredients: ["Hot dogs", "Mozzarella", "Panko breadcrumbs", "Potato cubes", "Batter mix"]
        }
      }
    }

    const lowerMessage = userMessage.toLowerCase()
    let response = {
      id: Date.now() + 1,
      type: 'ai',
      content: "I love your enthusiasm! Let me think of something delicious for you... 🤔 How about we start with what ingredients you have on hand?",
      timestamp: new Date()
    }

    for (const [key, value] of Object.entries(responses)) {
      if (lowerMessage.includes(key)) {
        response = {
          ...response,
          content: value.content,
          recipe: value.recipe
        }
        break
      }
    }

    return response
  }

  const handleQuickPrompt = (prompt) => {
    handleSendMessage(prompt)
  }

  return (
    <Card className="h-full flex flex-col bg-gradient-to-br from-white to-blue-50 dark:from-gray-900 dark:to-blue-900/20 border-0 shadow-xl">
      <CardHeader className="pb-3 bg-gradient-to-r from-blue-600 to-purple-600 text-white rounded-t-lg">
        <CardTitle className="flex items-center gap-2">
          <Bot className="h-5 w-5" />
          AI Kitchen Assistant
          <Sparkles className="h-4 w-4 text-yellow-300" />
        </CardTitle>
      </CardHeader>
      
      <CardContent className="flex-1 flex flex-col p-4">
        <div className="flex-1 overflow-y-auto space-y-4 mb-4">
          {messages.map((message) => (
            <div
              key={message.id}
              className={`flex ${message.type === 'user' ? 'justify-end' : 'justify-start'}`}
            >
              <div
                className={`max-w-[80%] rounded-lg p-3 ${
                  message.type === 'user'
                    ? 'bg-gradient-to-r from-blue-600 to-purple-600 text-white'
                    : 'bg-white dark:bg-gray-800 border shadow-sm'
                }`}
              >
                <div className="flex items-start gap-2">
                  {message.type === 'ai' && (
                    <ChefHat className="h-4 w-4 mt-1 text-blue-600 flex-shrink-0" />
                  )}
                  {message.type === 'user' && (
                    <User className="h-4 w-4 mt-1 text-white flex-shrink-0" />
                  )}
                  <div className="flex-1">
                    <p className="text-sm">{message.content}</p>
                    {message.recipe && (
                      <div className="mt-3 p-3 bg-gray-50 dark:bg-gray-700 rounded-lg">
                        <h4 className="font-semibold text-sm mb-2">{message.recipe.title}</h4>
                        <div className="flex gap-2 mb-2">
                          <Badge variant="outline" className="text-xs">
                            {message.recipe.cookTime}
                          </Badge>
                          <Badge variant="outline" className="text-xs">
                            {message.recipe.difficulty}
                          </Badge>
                        </div>
                        <p className="text-xs text-gray-600 dark:text-gray-300">
                          {message.recipe.ingredients.join(', ')}
                        </p>
                        {message.recipe && (
                          <Button
                            size="sm"
                            className="mt-2 w-full"
                            onClick={() => {
                              if (currentUser && (currentUser.subscription_tier === 'premium' || currentUser.subscription_tier === 'pro')) {
                                onRecipeGenerated && onRecipeGenerated(message.recipe);
                              } else {
                                alert('Upgrade to Premium or Pro to generate full recipes!');
                              }
                            }}
                          >
                            Generate Full Recipe
                          </Button>
                        )}
                      </div>
                    )}
                  </div>
                </div>
              </div>
            </div>
          ))}
          
          {isTyping && (
            <div className="flex justify-start">
              <div className="bg-white dark:bg-gray-800 border shadow-sm rounded-lg p-3">
                <div className="flex items-center gap-2">
                  <ChefHat className="h-4 w-4 text-blue-600" />
                  <div className="flex space-x-1">
                    <div className="w-2 h-2 bg-blue-600 rounded-full animate-bounce"></div>
                    <div className="w-2 h-2 bg-blue-600 rounded-full animate-bounce" style={{animationDelay: '0.1s'}}></div>
                    <div className="w-2 h-2 bg-blue-600 rounded-full animate-bounce" style={{animationDelay: '0.2s'}}></div>
                  </div>
                </div>
              </div>
            </div>
          )}
          <div ref={messagesEndRef} />
        </div>
        
        <div className="space-y-3">
          <div className="flex flex-wrap gap-2">
            {quickPrompts.map((prompt, index) => (
              <Button
                key={index}
                variant="outline"
                size="sm"
                onClick={() => handleQuickPrompt(prompt)}
                className="text-xs hover:bg-blue-50 dark:hover:bg-blue-900/20"
              >
                {prompt}
              </Button>
            ))}
          </div>
          
          <div className="flex gap-2">
            <Input
              value={inputValue}
              onChange={(e) => setInputValue(e.target.value)}
              placeholder="Ask me anything about cooking..."
              onKeyPress={(e) => e.key === 'Enter' && handleSendMessage()}
              className="flex-1"
            />
            <Button
              onClick={() => handleSendMessage()}
              disabled={!inputValue.trim() || isTyping}
              className="bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700"
            >
              <Send className="h-4 w-4" />
            </Button>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}

