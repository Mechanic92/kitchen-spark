from flask import Blueprint, request, jsonify, current_app
from flask_jwt_extended import jwt_required, get_jwt_identity
from datetime import datetime
import requests
from src.models.user import db, User, SavedRecipe, UserActivity

recipes_bp = Blueprint('recipes', __name__)

# Subscription tier limits
TIER_LIMITS = {
    'free': {
        'max_saved_recipes': 10,
        'ai_queries_per_day': 5
    },
    'premium': {
        'max_saved_recipes': -1,  # Unlimited
        'ai_queries_per_day': -1  # Unlimited
    },
    'pro': {
        'max_saved_recipes': -1,  # Unlimited
        'ai_queries_per_day': -1  # Unlimited
    }
}

def check_subscription_limit(user, limit_type):
    """Check if user has reached their subscription limit"""
    tier = user.subscription_tier
    limits = TIER_LIMITS.get(tier, TIER_LIMITS['free'])
    
    if limit_type == 'saved_recipes':
        max_recipes = limits['max_saved_recipes']
        if max_recipes == -1:  # Unlimited
            return True, 0
        
        current_count = SavedRecipe.query.filter_by(user_id=user.id).count()
        return current_count < max_recipes, current_count
    
    return True, 0

def fetch_recipe_details(recipe_id, source='themealdb'):
    """Fetch recipe details from external API"""
    try:
        if source == 'themealdb':
            url = f"https://www.themealdb.com/api/json/v1/1/lookup.php?i={recipe_id}"
            response = requests.get(url, timeout=10)
            
            if response.status_code == 200:
                data = response.json()
                if data.get('meals') and len(data['meals']) > 0:
                    meal = data['meals'][0]
                    return {
                        'id': meal['idMeal'],
                        'title': meal['strMeal'],
                        'image_url': meal['strMealThumb'],
                        'category': meal.get('strCategory'),
                        'area': meal.get('strArea'),
                        'instructions': meal.get('strInstructions'),
                        'source': 'themealdb'
                    }
        return None
    except Exception as e:
        current_app.logger.error(f"Error fetching recipe details: {str(e)}")
        return None

@recipes_bp.route('/save', methods=['POST'])
@jwt_required()
def save_recipe():
    """Save a recipe to user's collection"""
    try:
        user_id = get_jwt_identity()
        user = User.query.get(user_id)
        
        if not user:
            return jsonify({'error': 'User not found'}), 404
        
        data = request.get_json()
        
        # Validate required fields
        if not data.get('recipe_id'):
            return jsonify({'error': 'Recipe ID is required'}), 400
        
        recipe_id = str(data['recipe_id'])
        recipe_source = data.get('recipe_source', 'themealdb')
        
        # Check subscription limits
        can_save, current_count = check_subscription_limit(user, 'saved_recipes')
        if not can_save:
            return jsonify({
                'error': 'Recipe save limit reached',
                'message': f'Free tier allows up to {TIER_LIMITS["free"]["max_saved_recipes"]} saved recipes. Upgrade to Premium for unlimited saves.',
                'current_count': current_count,
                'limit': TIER_LIMITS['free']['max_saved_recipes'],
                'upgrade_required': True
            }), 403
        
        # Check if recipe is already saved
        existing_recipe = SavedRecipe.query.filter_by(
            user_id=user_id,
            recipe_id=recipe_id,
            recipe_source=recipe_source
        ).first()
        
        if existing_recipe:
            return jsonify({'error': 'Recipe already saved'}), 409
        
        # Fetch recipe details if not provided
        recipe_title = data.get('recipe_title')
        recipe_image_url = data.get('recipe_image_url')
        
        if not recipe_title or not recipe_image_url:
            recipe_details = fetch_recipe_details(recipe_id, recipe_source)
            if recipe_details:
                recipe_title = recipe_details['title']
                recipe_image_url = recipe_details['image_url']
        
        # Create saved recipe
        saved_recipe = SavedRecipe(
            user_id=user_id,
            recipe_id=recipe_id,
            recipe_title=recipe_title,
            recipe_image_url=recipe_image_url,
            recipe_source=recipe_source,
            notes=data.get('notes', ''),
            rating=data.get('rating')
        )
        
        db.session.add(saved_recipe)
        db.session.commit()
        
        # Log activity
        activity = UserActivity(
            user_id=user_id,
            activity_type='recipe_saved',
            recipe_id=recipe_id,
            metadata=f'{{"source": "{recipe_source}", "title": "{recipe_title}"}}'
        )
        db.session.add(activity)
        db.session.commit()
        
        return jsonify({
            'message': 'Recipe saved successfully',
            'recipe': saved_recipe.to_dict()
        }), 201
        
    except Exception as e:
        db.session.rollback()
        current_app.logger.error(f"Save recipe error: {str(e)}")
        return jsonify({'error': 'Failed to save recipe'}), 500

@recipes_bp.route('/saved', methods=['GET'])
@jwt_required()
def get_saved_recipes():
    """Get user's saved recipes"""
    try:
        user_id = get_jwt_identity()
        user = User.query.get(user_id)
        
        if not user:
            return jsonify({'error': 'User not found'}), 404
        
        # Get query parameters
        page = request.args.get('page', 1, type=int)
        per_page = min(request.args.get('per_page', 20, type=int), 100)
        search = request.args.get('search', '').strip()
        source = request.args.get('source', '').strip()
        
        # Build query
        query = SavedRecipe.query.filter_by(user_id=user_id)
        
        if search:
            query = query.filter(SavedRecipe.recipe_title.ilike(f'%{search}%'))
        
        if source:
            query = query.filter_by(recipe_source=source)
        
        # Order by saved date (newest first)
        query = query.order_by(SavedRecipe.saved_at.desc())
        
        # Paginate
        pagination = query.paginate(
            page=page,
            per_page=per_page,
            error_out=False
        )
        
        recipes = [recipe.to_dict() for recipe in pagination.items]
        
        return jsonify({
            'recipes': recipes,
            'pagination': {
                'page': page,
                'per_page': per_page,
                'total': pagination.total,
                'pages': pagination.pages,
                'has_next': pagination.has_next,
                'has_prev': pagination.has_prev
            },
            'subscription_info': {
                'tier': user.subscription_tier,
                'saved_count': pagination.total,
                'limit': TIER_LIMITS[user.subscription_tier]['max_saved_recipes']
            }
        }), 200
        
    except Exception as e:
        current_app.logger.error(f"Get saved recipes error: {str(e)}")
        return jsonify({'error': 'Failed to get saved recipes'}), 500

@recipes_bp.route('/saved/<int:recipe_db_id>', methods=['DELETE'])
@jwt_required()
def remove_saved_recipe(recipe_db_id):
    """Remove a recipe from user's saved collection"""
    try:
        user_id = get_jwt_identity()
        
        # Find the saved recipe
        saved_recipe = SavedRecipe.query.filter_by(
            id=recipe_db_id,
            user_id=user_id
        ).first()
        
        if not saved_recipe:
            return jsonify({'error': 'Saved recipe not found'}), 404
        
        # Log activity before deletion
        activity = UserActivity(
            user_id=user_id,
            activity_type='recipe_removed',
            recipe_id=saved_recipe.recipe_id,
            metadata=f'{{"source": "{saved_recipe.recipe_source}", "title": "{saved_recipe.recipe_title}"}}'
        )
        db.session.add(activity)
        
        # Remove the saved recipe
        db.session.delete(saved_recipe)
        db.session.commit()
        
        return jsonify({
            'message': 'Recipe removed successfully'
        }), 200
        
    except Exception as e:
        db.session.rollback()
        current_app.logger.error(f"Remove saved recipe error: {str(e)}")
        return jsonify({'error': 'Failed to remove recipe'}), 500

@recipes_bp.route('/saved/<int:recipe_db_id>/notes', methods=['PUT'])
@jwt_required()
def update_recipe_notes(recipe_db_id):
    """Update notes for a saved recipe"""
    try:
        user_id = get_jwt_identity()
        
        # Find the saved recipe
        saved_recipe = SavedRecipe.query.filter_by(
            id=recipe_db_id,
            user_id=user_id
        ).first()
        
        if not saved_recipe:
            return jsonify({'error': 'Saved recipe not found'}), 404
        
        data = request.get_json()
        notes = data.get('notes', '').strip()
        
        # Update notes
        saved_recipe.notes = notes
        db.session.commit()
        
        # Log activity
        activity = UserActivity(
            user_id=user_id,
            activity_type='recipe_notes_updated',
            recipe_id=saved_recipe.recipe_id,
            metadata=f'{{"source": "{saved_recipe.recipe_source}", "notes_length": {len(notes)}}}'
        )
        db.session.add(activity)
        db.session.commit()
        
        return jsonify({
            'message': 'Notes updated successfully',
            'recipe': saved_recipe.to_dict()
        }), 200
        
    except Exception as e:
        db.session.rollback()
        current_app.logger.error(f"Update recipe notes error: {str(e)}")
        return jsonify({'error': 'Failed to update notes'}), 500

@recipes_bp.route('/saved/<int:recipe_db_id>/rating', methods=['PUT'])
@jwt_required()
def update_recipe_rating(recipe_db_id):
    """Update rating for a saved recipe"""
    try:
        user_id = get_jwt_identity()
        
        # Find the saved recipe
        saved_recipe = SavedRecipe.query.filter_by(
            id=recipe_db_id,
            user_id=user_id
        ).first()
        
        if not saved_recipe:
            return jsonify({'error': 'Saved recipe not found'}), 404
        
        data = request.get_json()
        rating = data.get('rating')
        
        # Validate rating
        if rating is not None and (not isinstance(rating, int) or rating < 1 or rating > 5):
            return jsonify({'error': 'Rating must be between 1 and 5'}), 400
        
        # Update rating
        saved_recipe.rating = rating
        db.session.commit()
        
        # Log activity
        activity = UserActivity(
            user_id=user_id,
            activity_type='recipe_rated',
            recipe_id=saved_recipe.recipe_id,
            metadata=f'{{"source": "{saved_recipe.recipe_source}", "rating": {rating}}}'
        )
        db.session.add(activity)
        db.session.commit()
        
        return jsonify({
            'message': 'Rating updated successfully',
            'recipe': saved_recipe.to_dict()
        }), 200
        
    except Exception as e:
        db.session.rollback()
        current_app.logger.error(f"Update recipe rating error: {str(e)}")
        return jsonify({'error': 'Failed to update rating'}), 500

@recipes_bp.route('/check-saved/<recipe_id>', methods=['GET'])
@jwt_required()
def check_recipe_saved(recipe_id):
    """Check if a recipe is saved by the user"""
    try:
        user_id = get_jwt_identity()
        recipe_source = request.args.get('source', 'themealdb')
        
        saved_recipe = SavedRecipe.query.filter_by(
            user_id=user_id,
            recipe_id=str(recipe_id),
            recipe_source=recipe_source
        ).first()
        
        return jsonify({
            'is_saved': saved_recipe is not None,
            'saved_recipe': saved_recipe.to_dict() if saved_recipe else None
        }), 200
        
    except Exception as e:
        current_app.logger.error(f"Check recipe saved error: {str(e)}")
        return jsonify({'error': 'Failed to check recipe status'}), 500

@recipes_bp.route('/discover', methods=['GET'])
def discover_recipes():
    """Discover recipes from TheMealDB (public endpoint)"""
    try:
        # Get query parameters
        category = request.args.get('category', '').strip()
        area = request.args.get('area', '').strip()
        search = request.args.get('search', '').strip()
        
        recipes = []
        
        if search:
            # Search by name
            url = f"https://www.themealdb.com/api/json/v1/1/search.php?s={search}"
        elif category:
            # Filter by category
            url = f"https://www.themealdb.com/api/json/v1/1/filter.php?c={category}"
        elif area:
            # Filter by area
            url = f"https://www.themealdb.com/api/json/v1/1/filter.php?a={area}"
        else:
            # Get random recipes
            url = "https://www.themealdb.com/api/json/v1/1/search.php?s="
        
        response = requests.get(url, timeout=10)
        
        if response.status_code == 200:
            data = response.json()
            if data.get('meals'):
                for meal in data['meals'][:20]:  # Limit to 20 recipes
                    recipe = {
                        'id': meal['idMeal'],
                        'title': meal['strMeal'],
                        'image': meal['strMealThumb'],
                        'category': meal.get('strCategory'),
                        'area': meal.get('strArea'),
                        'source': 'themealdb'
                    }
                    
                    # Add additional fields if available
                    if 'strInstructions' in meal:
                        recipe['description'] = meal['strInstructions'][:200] + '...' if len(meal['strInstructions']) > 200 else meal['strInstructions']
                    
                    recipes.append(recipe)
        
        return jsonify({
            'recipes': recipes,
            'total': len(recipes)
        }), 200
        
    except Exception as e:
        current_app.logger.error(f"Discover recipes error: {str(e)}")
        return jsonify({'error': 'Failed to discover recipes'}), 500

@recipes_bp.route('/subscription-limits', methods=['GET'])
@jwt_required()
def get_subscription_limits():
    """Get subscription limits for the current user"""
    try:
        user_id = get_jwt_identity()
        user = User.query.get(user_id)
        
        if not user:
            return jsonify({'error': 'User not found'}), 404
        
        tier = user.subscription_tier
        limits = TIER_LIMITS.get(tier, TIER_LIMITS['free'])
        
        # Get current usage
        saved_count = SavedRecipe.query.filter_by(user_id=user_id).count()
        
        return jsonify({
            'tier': tier,
            'limits': limits,
            'usage': {
                'saved_recipes': saved_count
            },
            'can_save_more': limits['max_saved_recipes'] == -1 or saved_count < limits['max_saved_recipes']
        }), 200
        
    except Exception as e:
        current_app.logger.error(f"Get subscription limits error: {str(e)}")
        return jsonify({'error': 'Failed to get subscription limits'}), 500

