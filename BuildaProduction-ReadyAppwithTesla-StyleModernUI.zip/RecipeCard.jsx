import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Clock, Users, Heart, ChefHat } from 'lucide-react'

export function RecipeCard({ recipe, onSave, onView, isSaved, isSaving }) {
  return (
    <Card className="group hover:shadow-xl transition-all duration-300 transform hover:-translate-y-1 bg-gradient-to-br from-white to-gray-50 dark:from-gray-900 dark:to-gray-800 border-0 shadow-lg">
      <div className="relative overflow-hidden rounded-t-lg">
        <img 
          src={recipe.image} 
          alt={recipe.title}
          className="w-full h-48 object-cover transition-transform duration-300 group-hover:scale-105"
        />
        <div className="absolute top-3 right-3">
          <Button
            variant="ghost"
            size="sm"
            onClick={(e) => {
              e.stopPropagation();
              onSave(recipe);
            }}
            disabled={isSaving}
            className={`bg-white/80 backdrop-blur-sm hover:bg-white/90 text-red-500 hover:text-red-600 rounded-full p-2 ${
              isSaving ? 'opacity-50 cursor-not-allowed' : ''
            }`}
          >
            {isSaving ? (
              <div className="w-4 h-4 border-2 border-current border-t-transparent rounded-full animate-spin"></div>
            ) : (
              <Heart className={`h-4 w-4 ${isSaved ? 'fill-current' : ''}`} />
            )}
          </Button>
        </div>
        <div className="absolute bottom-3 left-3">
          <Badge variant="secondary" className="bg-black/70 text-white backdrop-blur-sm">
            <ChefHat className="h-3 w-3 mr-1" />
            {recipe.difficulty}
          </Badge>
        </div>
      </div>
      
      <CardHeader className="pb-3">
        <CardTitle className="text-lg font-bold text-gray-900 dark:text-white line-clamp-2">
          {recipe.title}
        </CardTitle>
        <CardDescription className="text-sm text-gray-600 dark:text-gray-300 line-clamp-2">
          {recipe.description}
        </CardDescription>
      </CardHeader>
      
      <CardContent className="pt-0">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center space-x-4 text-sm text-gray-500 dark:text-gray-400">
            <div className="flex items-center">
              <Clock className="h-4 w-4 mr-1" />
              {recipe.cookTime}
            </div>
            <div className="flex items-center">
              <Users className="h-4 w-4 mr-1" />
              {recipe.servings}
            </div>
          </div>
          <div className="text-sm font-semibold text-green-600 dark:text-green-400">
            {recipe.calories} cal
          </div>
        </div>
        
        <div className="flex flex-wrap gap-1 mb-4">
          {recipe.tags.slice(0, 3).map((tag, index) => (
            <Badge key={index} variant="outline" className="text-xs">
              {tag}
            </Badge>
          ))}
          {recipe.tags.length > 3 && (
            <Badge variant="outline" className="text-xs">
              +{recipe.tags.length - 3}
            </Badge>
          )}
        </div>
        
        <Button 
          onClick={() => onView(recipe.id)}
          className="w-full bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 text-white font-medium transition-all duration-200"
        >
          View Recipe
        </Button>
      </CardContent>
    </Card>
  )
}

