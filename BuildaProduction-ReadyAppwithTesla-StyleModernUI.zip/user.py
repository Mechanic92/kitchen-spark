from flask_sqlalchemy import SQLAlchemy
from datetime import datetime
import json

db = SQLAlchemy()

class User(db.Model):
    __tablename__ = 'users'
    
    id = db.Column(db.Integer, primary_key=True)
    email = db.Column(db.String(255), unique=True, nullable=False)
    password_hash = db.Column(db.String(255), nullable=False)
    first_name = db.Column(db.String(100))
    last_name = db.Column(db.String(100))
    subscription_tier = db.Column(db.String(20), default='free')
    stripe_customer_id = db.Column(db.String(100))
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    last_login = db.Column(db.DateTime)
    is_active = db.Column(db.Boolean, default=True)
    email_verified = db.Column(db.Boolean, default=False)

    # Relationships
    saved_recipes = db.relationship('SavedRecipe', backref='user', lazy=True, cascade='all, delete-orphan')
    subscriptions = db.relationship('Subscription', backref='user', lazy=True, cascade='all, delete-orphan')
    payment_history = db.relationship('PaymentHistory', backref='user', lazy=True, cascade='all, delete-orphan')
    user_activity = db.relationship('UserActivity', backref='user', lazy=True, cascade='all, delete-orphan')
    user_preferences = db.relationship('UserPreferences', backref='user', lazy=True, cascade='all, delete-orphan')

    def __repr__(self):
        return f'<User {self.email}>'

    def to_dict(self):
        return {
            'id': self.id,
            'email': self.email,
            'first_name': self.first_name,
            'last_name': self.last_name,
            'subscription_tier': self.subscription_tier,
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'last_login': self.last_login.isoformat() if self.last_login else None,
            'is_active': self.is_active,
            'email_verified': self.email_verified
        }

class SavedRecipe(db.Model):
    __tablename__ = 'saved_recipes'
    
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    recipe_id = db.Column(db.String(100), nullable=False)
    recipe_title = db.Column(db.String(255))
    recipe_image_url = db.Column(db.Text)
    recipe_source = db.Column(db.String(50), default='themealdb')
    saved_at = db.Column(db.DateTime, default=datetime.utcnow)
    notes = db.Column(db.Text)
    rating = db.Column(db.Integer)

    __table_args__ = (db.UniqueConstraint('user_id', 'recipe_id', 'recipe_source'),)

    def to_dict(self):
        return {
            'id': self.id,
            'recipe_id': self.recipe_id,
            'recipe_title': self.recipe_title,
            'recipe_image_url': self.recipe_image_url,
            'recipe_source': self.recipe_source,
            'saved_at': self.saved_at.isoformat() if self.saved_at else None,
            'notes': self.notes,
            'rating': self.rating
        }

class Subscription(db.Model):
    __tablename__ = 'subscriptions'
    
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    stripe_subscription_id = db.Column(db.String(100), unique=True)
    tier = db.Column(db.String(20), nullable=False)
    status = db.Column(db.String(20), nullable=False)
    current_period_start = db.Column(db.DateTime)
    current_period_end = db.Column(db.DateTime)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    def to_dict(self):
        return {
            'id': self.id,
            'tier': self.tier,
            'status': self.status,
            'current_period_start': self.current_period_start.isoformat() if self.current_period_start else None,
            'current_period_end': self.current_period_end.isoformat() if self.current_period_end else None,
            'created_at': self.created_at.isoformat() if self.created_at else None
        }

class PaymentHistory(db.Model):
    __tablename__ = 'payment_history'
    
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    stripe_payment_intent_id = db.Column(db.String(100))
    amount = db.Column(db.Integer, nullable=False)  # Amount in cents
    currency = db.Column(db.String(3), default='usd')
    status = db.Column(db.String(20), nullable=False)
    description = db.Column(db.Text)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    def to_dict(self):
        return {
            'id': self.id,
            'amount': self.amount,
            'currency': self.currency,
            'status': self.status,
            'description': self.description,
            'created_at': self.created_at.isoformat() if self.created_at else None
        }

class UserActivity(db.Model):
    __tablename__ = 'user_activity'
    
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    activity_type = db.Column(db.String(50), nullable=False)
    recipe_id = db.Column(db.String(100))
    activity_metadata = db.Column(db.Text)  # JSON string (renamed from metadata)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    def get_metadata(self):
        return json.loads(self.activity_metadata) if self.activity_metadata else {}

    def set_metadata(self, data):
        self.activity_metadata = json.dumps(data) if data else None

    def to_dict(self):
        return {
            'id': self.id,
            'activity_type': self.activity_type,
            'recipe_id': self.recipe_id,
            'metadata': self.get_metadata(),
            'created_at': self.created_at.isoformat() if self.created_at else None
        }

class UserPreferences(db.Model):
    __tablename__ = 'user_preferences'
    
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    dietary_restrictions = db.Column(db.Text)  # JSON string
    favorite_cuisines = db.Column(db.Text)  # JSON string
    cooking_skill_level = db.Column(db.String(20))
    preferred_meal_types = db.Column(db.Text)  # JSON string
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    def get_dietary_restrictions(self):
        return json.loads(self.dietary_restrictions) if self.dietary_restrictions else []

    def set_dietary_restrictions(self, restrictions):
        self.dietary_restrictions = json.dumps(restrictions) if restrictions else None

    def get_favorite_cuisines(self):
        return json.loads(self.favorite_cuisines) if self.favorite_cuisines else []

    def set_favorite_cuisines(self, cuisines):
        self.favorite_cuisines = json.dumps(cuisines) if cuisines else None

    def get_preferred_meal_types(self):
        return json.loads(self.preferred_meal_types) if self.preferred_meal_types else []

    def set_preferred_meal_types(self, meal_types):
        self.preferred_meal_types = json.dumps(meal_types) if meal_types else None

    def to_dict(self):
        return {
            'id': self.id,
            'dietary_restrictions': self.get_dietary_restrictions(),
            'favorite_cuisines': self.get_favorite_cuisines(),
            'cooking_skill_level': self.cooking_skill_level,
            'preferred_meal_types': self.get_preferred_meal_types(),
            'updated_at': self.updated_at.isoformat() if self.updated_at else None
        }
