import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Progress } from '@/components/ui/progress'
import { Trophy, Star, TrendingUp, Award, Flame, Target, Calendar, ChefHat } from 'lucide-react'

export function ProgressDashboard() {
  const stats = {
    sparkPoints: 1250,
    recipesCompleted: 23,
    streakDays: 7,
    caloriesSaved: 3420,
    moneySaved: 127.50,
    skillLevel: 'Intermediate',
    weeklyGoal: 5,
    weeklyCompleted: 3
  }

  const achievements = [
    { id: 1, title: 'First Recipe', description: 'Completed your first recipe!', icon: ChefHat, earned: true, date: '2024-09-15' },
    { id: 2, title: 'Healthy Week', description: 'Cooked healthy meals for 7 days', icon: Target, earned: true, date: '2024-09-20' },
    { id: 3, title: 'Streak Master', description: 'Maintained a 7-day cooking streak', icon: Flame, earned: true, date: '2024-09-22' },
    { id: 4, title: 'Budget Chef', description: 'Saved $100 this month', icon: Trophy, earned: true, date: '2024-09-23' },
    { id: 5, title: 'Veggie Lover', description: 'Cook 10 vegetarian recipes', icon: Star, earned: false, progress: 7 },
    { id: 6, title: 'Speed Demon', description: 'Complete 5 quick recipes', icon: Award, earned: false, progress: 3 }
  ]

  const weeklyProgress = [
    { day: 'Mon', completed: true, recipe: 'Avocado Toast' },
    { day: 'Tue', completed: true, recipe: 'Quinoa Bowl' },
    { day: 'Wed', completed: true, recipe: 'Pasta Aglio' },
    { day: 'Thu', completed: false, recipe: null },
    { day: 'Fri', completed: false, recipe: null },
    { day: 'Sat', completed: false, recipe: null },
    { day: 'Sun', completed: false, recipe: null }
  ]

  const skillProgress = {
    current: 65,
    nextLevel: 'Advanced',
    pointsToNext: 350
  }

  return (
    <div className="space-y-6">
      {/* Main Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <Card className="bg-gradient-to-br from-yellow-400 to-orange-500 text-white border-0">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm opacity-90">Spark Points</p>
                <p className="text-2xl font-bold">{stats.sparkPoints.toLocaleString()}</p>
              </div>
              <Flame className="h-8 w-8 opacity-80" />
            </div>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-br from-green-400 to-emerald-500 text-white border-0">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm opacity-90">Recipes Completed</p>
                <p className="text-2xl font-bold">{stats.recipesCompleted}</p>
              </div>
              <ChefHat className="h-8 w-8 opacity-80" />
            </div>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-br from-blue-400 to-cyan-500 text-white border-0">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm opacity-90">Current Streak</p>
                <p className="text-2xl font-bold">{stats.streakDays} days</p>
              </div>
              <TrendingUp className="h-8 w-8 opacity-80" />
            </div>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-br from-purple-400 to-pink-500 text-white border-0">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm opacity-90">Money Saved</p>
                <p className="text-2xl font-bold">${stats.moneySaved}</p>
              </div>
              <Trophy className="h-8 w-8 opacity-80" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Skill Level Progress */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Star className="h-5 w-5 text-yellow-500" />
            Skill Level Progress
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="font-semibold text-lg">{stats.skillLevel}</p>
                <p className="text-sm text-gray-600 dark:text-gray-300">
                  {skillProgress.pointsToNext} points to {skillProgress.nextLevel}
                </p>
              </div>
              <Badge variant="outline" className="bg-yellow-50 text-yellow-700 border-yellow-200">
                Level 3
              </Badge>
            </div>
            <Progress value={skillProgress.current} className="h-3" />
            <div className="flex justify-between text-sm text-gray-600 dark:text-gray-300">
              <span>Beginner</span>
              <span>Intermediate</span>
              <span>Advanced</span>
              <span>Expert</span>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Weekly Challenge */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Calendar className="h-5 w-5 text-blue-500" />
            Weekly Challenge
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <p className="font-medium">Cook {stats.weeklyGoal} recipes this week</p>
              <Badge variant={stats.weeklyCompleted >= stats.weeklyGoal ? "default" : "secondary"}>
                {stats.weeklyCompleted}/{stats.weeklyGoal}
              </Badge>
            </div>
            <Progress value={(stats.weeklyCompleted / stats.weeklyGoal) * 100} className="h-2" />
            
            <div className="grid grid-cols-7 gap-2 mt-4">
              {weeklyProgress.map((day, index) => (
                <div key={index} className="text-center">
                  <div className={`w-10 h-10 rounded-full flex items-center justify-center text-sm font-medium mb-1 ${
                    day.completed 
                      ? 'bg-green-500 text-white' 
                      : 'bg-gray-200 dark:bg-gray-700 text-gray-600 dark:text-gray-300'
                  }`}>
                    {day.day.charAt(0)}
                  </div>
                  <p className="text-xs text-gray-600 dark:text-gray-300">
                    {day.recipe || 'Rest'}
                  </p>
                </div>
              ))}
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Achievements */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Trophy className="h-5 w-5 text-yellow-500" />
            Achievements
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {achievements.map((achievement) => {
              const IconComponent = achievement.icon
              return (
                <div
                  key={achievement.id}
                  className={`p-4 rounded-lg border-2 transition-all ${
                    achievement.earned
                      ? 'border-yellow-200 bg-yellow-50 dark:bg-yellow-900/20 dark:border-yellow-800'
                      : 'border-gray-200 bg-gray-50 dark:bg-gray-800 dark:border-gray-700'
                  }`}
                >
                  <div className="flex items-start gap-3">
                    <div className={`p-2 rounded-full ${
                      achievement.earned 
                        ? 'bg-yellow-500 text-white' 
                        : 'bg-gray-300 dark:bg-gray-600 text-gray-600 dark:text-gray-300'
                    }`}>
                      <IconComponent className="h-4 w-4" />
                    </div>
                    <div className="flex-1">
                      <h3 className="font-semibold">{achievement.title}</h3>
                      <p className="text-sm text-gray-600 dark:text-gray-300 mb-2">
                        {achievement.description}
                      </p>
                      {achievement.earned ? (
                        <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200">
                          Earned {achievement.date}
                        </Badge>
                      ) : (
                        <div className="space-y-1">
                          <Progress value={(achievement.progress / 10) * 100} className="h-1" />
                          <p className="text-xs text-gray-500">
                            {achievement.progress}/10 progress
                          </p>
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              )
            })}
          </div>
        </CardContent>
      </Card>

      {/* Health & Savings Impact */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <Card className="bg-gradient-to-br from-green-50 to-emerald-50 dark:from-green-900/20 dark:to-emerald-900/20 border-green-200 dark:border-green-800">
          <CardHeader>
            <CardTitle className="text-green-800 dark:text-green-200">Health Impact</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              <div className="flex justify-between">
                <span>Calories Saved</span>
                <span className="font-semibold">{stats.caloriesSaved.toLocaleString()}</span>
              </div>
              <div className="flex justify-between">
                <span>Healthy Meals</span>
                <span className="font-semibold">18/23</span>
              </div>
              <div className="flex justify-between">
                <span>Veggie Servings</span>
                <span className="font-semibold">45 this week</span>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-br from-blue-50 to-cyan-50 dark:from-blue-900/20 dark:to-cyan-900/20 border-blue-200 dark:border-blue-800">
          <CardHeader>
            <CardTitle className="text-blue-800 dark:text-blue-200">Financial Impact</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              <div className="flex justify-between">
                <span>Money Saved</span>
                <span className="font-semibold">${stats.moneySaved}</span>
              </div>
              <div className="flex justify-between">
                <span>Avg. Cost per Meal</span>
                <span className="font-semibold">$4.20</span>
              </div>
              <div className="flex justify-between">
                <span>vs. Takeout Savings</span>
                <span className="font-semibold text-green-600">65%</span>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}

