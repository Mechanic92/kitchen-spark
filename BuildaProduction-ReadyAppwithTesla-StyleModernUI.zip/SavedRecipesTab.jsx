import React, { useState, useEffect } from 'react';
import { Heart, Search, Star, Trash2, Edit3, Save, X, BookOpen, Clock, Users } from 'lucide-react';
import savedRecipesService from '../services/savedRecipesService';
import authService from '../services/authService';

const SavedRecipesTab = ({ onRecipeClick }) => {
  const [savedRecipes, setSavedRecipes] = useState([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [subscriptionInfo, setSubscriptionInfo] = useState(null);
  const [editingNotes, setEditingNotes] = useState(null);
  const [editingRating, setEditingRating] = useState(null);
  const [tempNotes, setTempNotes] = useState('');
  const [tempRating, setTempRating] = useState(0);

  useEffect(() => {
    if (authService.isAuthenticated()) {
      loadSavedRecipes();
    }
  }, []);

  const loadSavedRecipes = async () => {
    setLoading(true);
    try {
      const result = await savedRecipesService.getSavedRecipes({
        search: searchTerm,
        per_page: 50
      });

      if (result.success) {
        setSavedRecipes(result.recipes);
        setSubscriptionInfo(result.subscriptionInfo);
      } else {
        console.error('Failed to load saved recipes:', result.error);
      }
    } catch (error) {
      console.error('Error loading saved recipes:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleSearch = () => {
    loadSavedRecipes();
  };

  const handleRemoveRecipe = async (recipeDbId) => {
    if (!confirm('Are you sure you want to remove this recipe from your saved collection?')) {
      return;
    }

    try {
      const result = await savedRecipesService.removeSavedRecipe(recipeDbId);
      if (result.success) {
        setSavedRecipes(prev => prev.filter(recipe => recipe.id !== recipeDbId));
      } else {
        alert('Failed to remove recipe: ' + result.error);
      }
    } catch (error) {
      console.error('Error removing recipe:', error);
      alert('Failed to remove recipe');
    }
  };

  const handleEditNotes = (recipe) => {
    setEditingNotes(recipe.id);
    setTempNotes(recipe.notes || '');
  };

  const handleSaveNotes = async (recipeDbId) => {
    try {
      const result = await savedRecipesService.updateRecipeNotes(recipeDbId, tempNotes);
      if (result.success) {
        setSavedRecipes(prev => prev.map(recipe => 
          recipe.id === recipeDbId ? { ...recipe, notes: tempNotes } : recipe
        ));
        setEditingNotes(null);
      } else {
        alert('Failed to update notes: ' + result.error);
      }
    } catch (error) {
      console.error('Error updating notes:', error);
      alert('Failed to update notes');
    }
  };

  const handleCancelNotes = () => {
    setEditingNotes(null);
    setTempNotes('');
  };

  const handleEditRating = (recipe) => {
    setEditingRating(recipe.id);
    setTempRating(recipe.rating || 0);
  };

  const handleSaveRating = async (recipeDbId) => {
    try {
      const result = await savedRecipesService.updateRecipeRating(recipeDbId, tempRating);
      if (result.success) {
        setSavedRecipes(prev => prev.map(recipe => 
          recipe.id === recipeDbId ? { ...recipe, rating: tempRating } : recipe
        ));
        setEditingRating(null);
      } else {
        alert('Failed to update rating: ' + result.error);
      }
    } catch (error) {
      console.error('Error updating rating:', error);
      alert('Failed to update rating');
    }
  };

  const renderStars = (rating, isEditing = false, onStarClick = null) => {
    return (
      <div className="flex gap-1">
        {[1, 2, 3, 4, 5].map((star) => (
          <Star
            key={star}
            size={16}
            className={`${
              star <= rating
                ? 'text-yellow-400 fill-yellow-400'
                : 'text-gray-300'
            } ${isEditing ? 'cursor-pointer hover:text-yellow-400' : ''}`}
            onClick={isEditing ? () => onStarClick(star) : undefined}
          />
        ))}
      </div>
    );
  };

  if (!authService.isAuthenticated()) {
    return (
      <div className="text-center py-12">
        <BookOpen size={64} className="mx-auto text-gray-300 mb-4" />
        <h3 className="text-xl font-semibold text-gray-700 mb-2">Sign In to Save Recipes</h3>
        <p className="text-gray-500">
          Create an account to save your favorite recipes and access them anytime.
        </p>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row gap-4 items-start sm:items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold text-gray-800">My Saved Recipes</h2>
          {subscriptionInfo && (
            <p className="text-sm text-gray-600 mt-1">
              {subscriptionInfo.saved_count} saved recipes
              {subscriptionInfo.limit !== -1 && ` (${subscriptionInfo.limit} max)`}
              {subscriptionInfo.tier === 'free' && (
                <span className="text-orange-500 ml-2">
                  • Upgrade to Premium for unlimited saves
                </span>
              )}
            </p>
          )}
        </div>

        {/* Search */}
        <div className="flex gap-2 w-full sm:w-auto">
          <div className="relative flex-1 sm:w-64">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" size={18} />
            <input
              type="text"
              placeholder="Search saved recipes..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              onKeyPress={(e) => e.key === 'Enter' && handleSearch()}
              className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-transparent"
            />
          </div>
          <button
            onClick={handleSearch}
            className="px-4 py-2 bg-orange-500 text-white rounded-lg hover:bg-orange-600 transition-colors"
          >
            Search
          </button>
        </div>
      </div>

      {/* Loading */}
      {loading && (
        <div className="flex justify-center py-12">
          <div className="w-8 h-8 border-4 border-orange-500/30 border-t-orange-500 rounded-full animate-spin"></div>
        </div>
      )}

      {/* Empty State */}
      {!loading && savedRecipes.length === 0 && (
        <div className="text-center py-12">
          <Heart size={64} className="mx-auto text-gray-300 mb-4" />
          <h3 className="text-xl font-semibold text-gray-700 mb-2">
            {searchTerm ? 'No recipes found' : 'No saved recipes yet'}
          </h3>
          <p className="text-gray-500">
            {searchTerm 
              ? 'Try adjusting your search terms'
              : 'Start exploring recipes and save your favorites!'
            }
          </p>
        </div>
      )}

      {/* Recipe Grid */}
      {!loading && savedRecipes.length > 0 && (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {savedRecipes.map((recipe) => (
            <div key={recipe.id} className="bg-white rounded-xl shadow-lg overflow-hidden hover:shadow-xl transition-all duration-300 group">
              {/* Recipe Image */}
              <div className="relative h-48 overflow-hidden">
                <img
                  src={recipe.recipe_image_url}
                  alt={recipe.recipe_title}
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/50 to-transparent" />
                
                {/* Action Buttons */}
                <div className="absolute top-3 right-3 flex gap-2">
                  <button
                    onClick={() => handleRemoveRecipe(recipe.id)}
                    className="p-2 bg-red-500/80 hover:bg-red-500 text-white rounded-full transition-colors"
                    title="Remove from saved"
                  >
                    <Trash2 size={16} />
                  </button>
                </div>

                {/* Saved Date */}
                <div className="absolute bottom-3 left-3 text-white text-sm">
                  <Clock size={14} className="inline mr-1" />
                  Saved {new Date(recipe.saved_at).toLocaleDateString()}
                </div>
              </div>

              {/* Recipe Info */}
              <div className="p-4 space-y-3">
                <h3 
                  className="font-semibold text-gray-800 line-clamp-2 cursor-pointer hover:text-orange-500 transition-colors"
                  onClick={() => onRecipeClick && onRecipeClick(recipe.recipe_id, recipe.recipe_source)}
                >
                  {recipe.recipe_title}
                </h3>

                {/* Rating */}
                <div className="flex items-center justify-between">
                  <span className="text-sm text-gray-600">Rating:</span>
                  {editingRating === recipe.id ? (
                    <div className="flex items-center gap-2">
                      {renderStars(tempRating, true, setTempRating)}
                      <button
                        onClick={() => handleSaveRating(recipe.id)}
                        className="p-1 text-green-500 hover:text-green-600"
                      >
                        <Save size={14} />
                      </button>
                      <button
                        onClick={() => setEditingRating(null)}
                        className="p-1 text-gray-500 hover:text-gray-600"
                      >
                        <X size={14} />
                      </button>
                    </div>
                  ) : (
                    <div className="flex items-center gap-2">
                      {renderStars(recipe.rating || 0)}
                      <button
                        onClick={() => handleEditRating(recipe)}
                        className="p-1 text-gray-400 hover:text-gray-600"
                      >
                        <Edit3 size={14} />
                      </button>
                    </div>
                  )}
                </div>

                {/* Notes */}
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-gray-600">Notes:</span>
                    {editingNotes !== recipe.id && (
                      <button
                        onClick={() => handleEditNotes(recipe)}
                        className="p-1 text-gray-400 hover:text-gray-600"
                      >
                        <Edit3 size={14} />
                      </button>
                    )}
                  </div>
                  
                  {editingNotes === recipe.id ? (
                    <div className="space-y-2">
                      <textarea
                        value={tempNotes}
                        onChange={(e) => setTempNotes(e.target.value)}
                        placeholder="Add your cooking notes..."
                        className="w-full p-2 text-sm border border-gray-300 rounded focus:ring-2 focus:ring-orange-500 focus:border-transparent resize-none"
                        rows={3}
                      />
                      <div className="flex gap-2">
                        <button
                          onClick={() => handleSaveNotes(recipe.id)}
                          className="flex-1 px-3 py-1 bg-green-500 text-white text-sm rounded hover:bg-green-600 transition-colors"
                        >
                          Save
                        </button>
                        <button
                          onClick={handleCancelNotes}
                          className="flex-1 px-3 py-1 bg-gray-500 text-white text-sm rounded hover:bg-gray-600 transition-colors"
                        >
                          Cancel
                        </button>
                      </div>
                    </div>
                  ) : (
                    <p className="text-sm text-gray-700 min-h-[3rem]">
                      {recipe.notes || 'No notes added yet'}
                    </p>
                  )}
                </div>

                {/* View Recipe Button */}
                <button
                  onClick={() => onRecipeClick && onRecipeClick(recipe.recipe_id, recipe.recipe_source)}
                  className="w-full mt-3 px-4 py-2 bg-gradient-to-r from-orange-500 to-red-500 text-white rounded-lg hover:from-orange-600 hover:to-red-600 transition-all transform hover:scale-[1.02]"
                >
                  View Recipe
                </button>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

export { SavedRecipesTab };

