import { useState } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Checkbox } from '@/components/ui/checkbox'
import { Badge } from '@/components/ui/badge'
import { ShoppingCart, Plus, Trash2, DollarSign, Leaf, Clock, Zap } from 'lucide-react'

export function ShoppingList() {
  const [items, setItems] = useState([
    { id: 1, name: 'Organic Spinach', category: 'Vegetables', price: 3.99, checked: false, healthy: true, onSale: false },
    { id: 2, name: 'Free-range Eggs', category: 'Dairy', price: 4.50, checked: false, healthy: true, onSale: true },
    { id: 3, name: 'Quinoa', category: 'Grains', price: 6.99, checked: true, healthy: true, onSale: false },
    { id: 4, name: 'Avocados', category: 'Fruits', price: 2.99, checked: false, healthy: true, onSale: true },
    { id: 5, name: 'Greek Yogurt', category: 'Dairy', price: 5.99, checked: false, healthy: true, onSale: false },
  ])
  const [newItem, setNewItem] = useState('')

  const addItem = () => {
    if (newItem.trim()) {
      const item = {
        id: Date.now(),
        name: newItem,
        category: 'Other',
        price: 0,
        checked: false,
        healthy: false,
        onSale: false
      }
      setItems([...items, item])
      setNewItem('')
    }
  }

  const toggleItem = (id) => {
    setItems(items.map(item => 
      item.id === id ? { ...item, checked: !item.checked } : item
    ))
  }

  const removeItem = (id) => {
    setItems(items.filter(item => item.id !== id))
  }

  const totalPrice = items.reduce((sum, item) => sum + (item.checked ? 0 : item.price), 0)
  const checkedItems = items.filter(item => item.checked).length
  const totalItems = items.length

  const categories = [...new Set(items.map(item => item.category))]

  const aiSuggestions = [
    { name: 'Sweet Potatoes', reason: 'Great source of vitamins, on sale this week!' },
    { name: 'Salmon Fillet', reason: 'Perfect for your healthy dinner goals' },
    { name: 'Blueberries', reason: 'Antioxidant powerhouse, seasonal pick' }
  ]

  return (
    <div className="space-y-6">
      {/* Header Stats */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card className="bg-gradient-to-r from-green-500 to-emerald-600 text-white border-0">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm opacity-90">Total Budget</p>
                <p className="text-2xl font-bold">${totalPrice.toFixed(2)}</p>
              </div>
              <DollarSign className="h-8 w-8 opacity-80" />
            </div>
          </CardContent>
        </Card>
        
        <Card className="bg-gradient-to-r from-blue-500 to-cyan-600 text-white border-0">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm opacity-90">Progress</p>
                <p className="text-2xl font-bold">{checkedItems}/{totalItems}</p>
              </div>
              <ShoppingCart className="h-8 w-8 opacity-80" />
            </div>
          </CardContent>
        </Card>
        
        <Card className="bg-gradient-to-r from-purple-500 to-pink-600 text-white border-0">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm opacity-90">Healthy Items</p>
                <p className="text-2xl font-bold">{items.filter(item => item.healthy).length}</p>
              </div>
              <Leaf className="h-8 w-8 opacity-80" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* AI Suggestions */}
      <Card className="bg-gradient-to-br from-yellow-50 to-orange-50 dark:from-yellow-900/20 dark:to-orange-900/20 border-yellow-200 dark:border-yellow-800">
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-orange-800 dark:text-orange-200">
            <Zap className="h-5 w-5" />
            AI Smart Suggestions
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {aiSuggestions.map((suggestion, index) => (
              <div key={index} className="flex items-center justify-between p-3 bg-white dark:bg-gray-800 rounded-lg shadow-sm">
                <div>
                  <p className="font-medium">{suggestion.name}</p>
                  <p className="text-sm text-gray-600 dark:text-gray-300">{suggestion.reason}</p>
                </div>
                <Button size="sm" variant="outline" onClick={() => {
                  const newSuggestion = {
                    id: Date.now(),
                    name: suggestion.name,
                    category: 'AI Suggested',
                    price: Math.random() * 10 + 2,
                    checked: false,
                    healthy: true,
                    onSale: Math.random() > 0.5
                  }
                  setItems([...items, newSuggestion])
                }}>
                  <Plus className="h-4 w-4" />
                </Button>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Add New Item */}
      <Card>
        <CardHeader>
          <CardTitle>Add Items</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex gap-2">
            <Input
              value={newItem}
              onChange={(e) => setNewItem(e.target.value)}
              placeholder="Add new item..."
              onKeyPress={(e) => e.key === 'Enter' && addItem()}
              className="flex-1"
            />
            <Button onClick={addItem} className="bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700">
              <Plus className="h-4 w-4" />
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Shopping List by Category */}
      <div className="space-y-4">
        {categories.map(category => (
          <Card key={category}>
            <CardHeader className="pb-3">
              <CardTitle className="text-lg">{category}</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {items.filter(item => item.category === category).map(item => (
                  <div key={item.id} className="flex items-center justify-between p-3 bg-gray-50 dark:bg-gray-800 rounded-lg">
                    <div className="flex items-center space-x-3">
                      <Checkbox
                        checked={item.checked}
                        onCheckedChange={() => toggleItem(item.id)}
                      />
                      <div className="flex-1">
                        <p className={`font-medium ${item.checked ? 'line-through text-gray-500' : ''}`}>
                          {item.name}
                        </p>
                        <div className="flex items-center gap-2 mt-1">
                          <span className="text-sm font-semibold text-green-600">
                            ${item.price.toFixed(2)}
                          </span>
                          {item.healthy && (
                            <Badge variant="outline" className="text-xs bg-green-50 text-green-700 border-green-200">
                              <Leaf className="h-3 w-3 mr-1" />
                              Healthy
                            </Badge>
                          )}
                          {item.onSale && (
                            <Badge variant="outline" className="text-xs bg-red-50 text-red-700 border-red-200">
                              <Clock className="h-3 w-3 mr-1" />
                              On Sale
                            </Badge>
                          )}
                        </div>
                      </div>
                    </div>
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => removeItem(item.id)}
                      className="text-red-500 hover:text-red-700 hover:bg-red-50"
                    >
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  )
}

