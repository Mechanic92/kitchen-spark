// Recipe Service for Kitchen Spark
// Integrates with TheMealDB API for real recipe data

const MEAL_DB_BASE_URL = 'https://www.themealdb.com/api/json/v1/1';

// Enhanced recipe database with more variety
const ENHANCED_RECIPES = [
  {
    id: 'ks_001',
    title: "Lightning Pasta Aglio e Olio",
    description: "Simple yet elegant pasta with garlic, olive oil, and red pepper flakes. Perfect for lazy evenings!",
    image: "https://images.unsplash.com/photo-1621996346565-e3dbc353d2e5?w=400&h=300&fit=crop",
    cookTime: "12 mins",
    servings: "2",
    calories: 420,
    difficulty: "Easy",
    tags: ["Quick", "Italian", "Vegetarian"],
    ingredients: [
      "400g spaghetti",
      "6 cloves garlic, thinly sliced",
      "1/2 cup extra virgin olive oil",
      "1/2 tsp red pepper flakes",
      "1/4 cup fresh parsley, chopped",
      "1/2 cup Parmesan cheese, grated",
      "Salt and black pepper to taste"
    ],
    instructions: [
      "Bring a large pot of salted water to boil. Cook spaghetti according to package directions until al dente.",
      "While pasta cooks, heat olive oil in a large skillet over medium heat.",
      "Add sliced garlic and red pepper flakes. Cook until garlic is golden, about 2-3 minutes.",
      "Drain pasta, reserving 1 cup pasta water. Add pasta to the skillet with garlic oil.",
      "Toss pasta with oil, adding pasta water as needed to create a silky sauce.",
      "Remove from heat, add parsley and Parmesan. Season with salt and pepper.",
      "Serve immediately with extra Parmesan on the side."
    ],
    nutrition: {
      calories: 420,
      protein: "14g",
      carbs: "58g",
      fat: "16g",
      fiber: "3g"
    },
    tips: [
      "Don't let the garlic burn - it will become bitter",
      "Save some pasta water - the starch helps bind the sauce",
      "Use the best quality olive oil you have for maximum flavor"
    ]
  },
  {
    id: 'ks_002',
    title: "Rainbow Buddha Bowl",
    description: "Colorful, nutritious bowl packed with quinoa, roasted chickpeas, and fresh vegetables.",
    image: "https://images.unsplash.com/photo-1512621776951-a57141f2eefd?w=400&h=300&fit=crop",
    cookTime: "25 mins",
    servings: "1",
    calories: 380,
    difficulty: "Easy",
    tags: ["Healthy", "Vegan", "Colorful"],
    ingredients: [
      "1/2 cup quinoa",
      "1 cup chickpeas, drained and rinsed",
      "1 cup purple cabbage, shredded",
      "1 carrot, julienned",
      "1/2 avocado, sliced",
      "1/4 cup edamame",
      "2 tbsp tahini",
      "1 tbsp lemon juice",
      "1 tsp maple syrup",
      "1 clove garlic, minced"
    ],
    instructions: [
      "Cook quinoa according to package directions. Let cool slightly.",
      "Preheat oven to 400°F. Toss chickpeas with olive oil, salt, and cumin. Roast for 20 minutes.",
      "Make tahini dressing by whisking together tahini, lemon juice, maple syrup, garlic, and 2-3 tbsp water.",
      "Arrange quinoa in a bowl. Top with roasted chickpeas, cabbage, carrot, avocado, and edamame.",
      "Drizzle with tahini dressing and serve immediately."
    ],
    nutrition: {
      calories: 380,
      protein: "16g",
      carbs: "45g",
      fat: "18g",
      fiber: "12g"
    },
    tips: [
      "Prep ingredients ahead for quick assembly",
      "Add a sprinkle of hemp seeds for extra nutrition",
      "Customize with your favorite seasonal vegetables"
    ]
  },
  {
    id: 'ks_003',
    title: "Korean Corn Dogs",
    description: "Crispy, cheesy Korean-style corn dogs with a unique potato coating. Adventure awaits!",
    image: "https://images.unsplash.com/photo-1565299624946-b28f40a0ca4b?w=400&h=300&fit=crop",
    cookTime: "30 mins",
    servings: "4",
    calories: 520,
    difficulty: "Medium",
    tags: ["Korean", "Street Food", "Crispy"],
    ingredients: [
      "4 hot dogs",
      "4 mozzarella cheese sticks",
      "1 cup all-purpose flour",
      "1/2 cup cornstarch",
      "1 tsp baking powder",
      "1 cup cold water",
      "2 cups panko breadcrumbs",
      "1 cup small potato cubes",
      "Oil for frying"
    ],
    instructions: [
      "Insert wooden sticks into hot dogs and cheese sticks.",
      "Mix flour, cornstarch, baking powder, and water to make batter.",
      "Dip hot dogs in batter, then roll in panko mixed with potato cubes.",
      "Heat oil to 350°F. Fry corn dogs for 3-4 minutes until golden.",
      "Serve hot with ketchup and mustard."
    ],
    nutrition: {
      calories: 520,
      protein: "18g",
      carbs: "42g",
      fat: "32g",
      fiber: "2g"
    },
    tips: [
      "Keep oil temperature consistent for even cooking",
      "Pat potato cubes dry before mixing with panko",
      "Serve immediately while coating is crispy"
    ]
  }
];

// Fetch recipes from TheMealDB API
export const fetchRecipesFromAPI = async (query = '', category = '', area = '') => {
  try {
    let url = '';
    
    if (query) {
      url = `${MEAL_DB_BASE_URL}/search.php?s=${encodeURIComponent(query)}`;
    } else if (category) {
      url = `${MEAL_DB_BASE_URL}/filter.php?c=${encodeURIComponent(category)}`;
    } else if (area) {
      url = `${MEAL_DB_BASE_URL}/filter.php?a=${encodeURIComponent(area)}`;
    } else {
      // Get random meals
      const randomPromises = Array(6).fill().map(() => 
        fetch(`${MEAL_DB_BASE_URL}/random.php`).then(res => res.json())
      );
      const randomResults = await Promise.all(randomPromises);
      return randomResults.map(result => transformMealDBRecipe(result.meals[0]));
    }

    const response = await fetch(url);
    const data = await response.json();
    
    if (data.meals) {
      return data.meals.map(meal => transformMealDBRecipe(meal));
    }
    
    return [];
  } catch (error) {
    console.error('Error fetching recipes from API:', error);
    return ENHANCED_RECIPES; // Fallback to local recipes
  }
};

// Transform MealDB recipe format to our app format
const transformMealDBRecipe = (meal) => {
  const ingredients = [];
  const instructions = meal.strInstructions ? meal.strInstructions.split('\r\n').filter(step => step.trim()) : [];
  
  // Extract ingredients and measurements
  for (let i = 1; i <= 20; i++) {
    const ingredient = meal[`strIngredient${i}`];
    const measure = meal[`strMeasure${i}`];
    
    if (ingredient && ingredient.trim()) {
      ingredients.push(`${measure ? measure.trim() + ' ' : ''}${ingredient.trim()}`);
    }
  }

  return {
    id: meal.idMeal,
    title: meal.strMeal,
    description: instructions[0] ? instructions[0].substring(0, 100) + '...' : 'Delicious recipe from around the world',
    image: meal.strMealThumb,
    cookTime: "30 mins", // Default since API doesn't provide this
    servings: "4", // Default
    calories: Math.floor(Math.random() * 200) + 300, // Estimated
    difficulty: ["Easy", "Medium", "Hard"][Math.floor(Math.random() * 3)],
    tags: [meal.strCategory, meal.strArea, ...(meal.strTags ? meal.strTags.split(',') : [])].filter(Boolean),
    ingredients,
    instructions,
    nutrition: {
      calories: Math.floor(Math.random() * 200) + 300,
      protein: Math.floor(Math.random() * 20) + 10 + "g",
      carbs: Math.floor(Math.random() * 40) + 20 + "g",
      fat: Math.floor(Math.random() * 15) + 5 + "g",
      fiber: Math.floor(Math.random() * 8) + 2 + "g"
    },
    tips: [
      "Follow cooking times carefully for best results",
      "Taste and adjust seasoning as needed",
      "Fresh ingredients make all the difference"
    ],
    category: meal.strCategory,
    area: meal.strArea,
    youtubeUrl: meal.strYoutube
  };
};

// Get recipe by ID
export const getRecipeById = async (id) => {
  // Check local recipes first
  const localRecipe = ENHANCED_RECIPES.find(recipe => recipe.id === id);
  if (localRecipe) return localRecipe;

  // Fetch from API
  try {
    const response = await fetch(`${MEAL_DB_BASE_URL}/lookup.php?i=${id}`);
    const data = await response.json();
    
    if (data.meals && data.meals[0]) {
      return transformMealDBRecipe(data.meals[0]);
    }
  } catch (error) {
    console.error('Error fetching recipe by ID:', error);
  }
  
  return null;
};

// Get random recipe
export const getRandomRecipe = async () => {
  try {
    const response = await fetch(`${MEAL_DB_BASE_URL}/random.php`);
    const data = await response.json();
    
    if (data.meals && data.meals[0]) {
      return transformMealDBRecipe(data.meals[0]);
    }
  } catch (error) {
    console.error('Error fetching random recipe:', error);
  }
  
  // Fallback to local random recipe
  return ENHANCED_RECIPES[Math.floor(Math.random() * ENHANCED_RECIPES.length)];
};

// Search recipes by ingredients
export const searchByIngredients = async (ingredients) => {
  try {
    const ingredient = ingredients[0]; // Use first ingredient for API call
    const response = await fetch(`${MEAL_DB_BASE_URL}/filter.php?i=${encodeURIComponent(ingredient)}`);
    const data = await response.json();
    
    if (data.meals) {
      return data.meals.slice(0, 6).map(meal => transformMealDBRecipe(meal));
    }
  } catch (error) {
    console.error('Error searching by ingredients:', error);
  }
  
  return ENHANCED_RECIPES;
};

// Get categories
export const getCategories = async () => {
  try {
    const response = await fetch(`${MEAL_DB_BASE_URL}/categories.php`);
    const data = await response.json();
    
    if (data.categories) {
      return data.categories.map(cat => ({
        name: cat.strCategory,
        description: cat.strCategoryDescription,
        image: cat.strCategoryThumb
      }));
    }
  } catch (error) {
    console.error('Error fetching categories:', error);
  }
  
  return [
    { name: 'Italian', description: 'Classic Italian cuisine' },
    { name: 'Asian', description: 'Flavors from across Asia' },
    { name: 'Healthy', description: 'Nutritious and delicious' },
    { name: 'Quick', description: 'Fast and easy meals' }
  ];
};

// Enhanced AI recipe generation with better responses
export const generateAIRecipe = (userInput) => {
  const input = userInput.toLowerCase();
  
  // More comprehensive recipe suggestions based on keywords
  const recipeDatabase = {
    'eggs': {
      recipes: [
        {
          title: "Perfect Fluffy Scrambled Eggs",
          cookTime: "5 mins",
          difficulty: "Easy",
          ingredients: ["3 large eggs", "2 tbsp butter", "2 tbsp heavy cream", "Salt & pepper", "Fresh chives"],
          description: "The secret to perfect scrambled eggs is low heat and patience. These come out incredibly creamy and fluffy!",
          instructions: [
            "Crack eggs into a cold pan with butter",
            "Turn heat to low and stir constantly with a spatula",
            "Add cream when eggs start to set",
            "Remove from heat while still slightly wet",
            "Season and garnish with chives"
          ]
        },
        {
          title: "Classic French Omelette",
          cookTime: "8 mins",
          difficulty: "Medium",
          ingredients: ["3 eggs", "2 tbsp butter", "2 tbsp gruyere cheese", "Fresh herbs", "Salt"],
          description: "A restaurant-quality omelette that's creamy on the inside with a perfect golden exterior."
        }
      ],
      tips: [
        "Room temperature eggs cook more evenly",
        "Never cook eggs on high heat",
        "Add a splash of cream for extra richness"
      ]
    },
    'healthy': {
      recipes: [
        {
          title: "Mediterranean Quinoa Bowl",
          cookTime: "20 mins",
          difficulty: "Easy",
          ingredients: ["1 cup quinoa", "Cherry tomatoes", "Cucumber", "Feta cheese", "Olive oil", "Lemon", "Fresh herbs"],
          description: "A protein-packed bowl full of Mediterranean flavors that will keep you satisfied and energized.",
          instructions: [
            "Cook quinoa according to package directions",
            "Dice tomatoes and cucumber",
            "Make lemon-herb dressing",
            "Combine all ingredients in a bowl",
            "Top with crumbled feta"
          ]
        }
      ],
      tips: [
        "Meal prep these bowls for the week",
        "Add different vegetables for variety",
        "Quinoa is a complete protein"
      ]
    },
    'quick': {
      recipes: [
        {
          title: "5-Minute Avocado Toast",
          cookTime: "5 mins",
          difficulty: "Easy",
          ingredients: ["2 slices sourdough bread", "1 ripe avocado", "Lemon juice", "Red pepper flakes", "Sea salt"],
          description: "Elevated avocado toast that's both quick and satisfying. Perfect for breakfast or a light lunch.",
          instructions: [
            "Toast bread until golden",
            "Mash avocado with lemon juice and salt",
            "Spread on toast",
            "Sprinkle with red pepper flakes",
            "Enjoy immediately"
          ]
        }
      ],
      tips: [
        "Choose ripe but firm avocados",
        "Add a fried egg for extra protein",
        "Try different bread varieties"
      ]
    },
    'comfort': {
      recipes: [
        {
          title: "Ultimate Mac and Cheese",
          cookTime: "25 mins",
          difficulty: "Medium",
          ingredients: ["1 lb pasta", "Sharp cheddar", "Gruyere", "Butter", "Flour", "Milk", "Breadcrumbs"],
          description: "The ultimate comfort food with a crispy top and incredibly creamy cheese sauce.",
          instructions: [
            "Cook pasta until al dente",
            "Make cheese sauce with butter, flour, and milk",
            "Add cheeses until melted",
            "Combine pasta and sauce",
            "Top with breadcrumbs and bake"
          ]
        }
      ],
      tips: [
        "Use a mix of cheeses for complex flavor",
        "Don't overcook the pasta",
        "Add mustard powder for depth"
      ]
    },
    'surprise': {
      recipes: [
        {
          title: "Fusion Kimchi Fried Rice",
          cookTime: "15 mins",
          difficulty: "Easy",
          ingredients: ["2 cups day-old rice", "1 cup kimchi", "2 eggs", "Sesame oil", "Soy sauce", "Green onions"],
          description: "A fusion twist that combines Korean flavors with fried rice. Umami-packed and surprisingly addictive!",
          instructions: [
            "Heat sesame oil in a large pan",
            "Add kimchi and cook for 2 minutes",
            "Add rice and break up clumps",
            "Push rice to one side, scramble eggs",
            "Mix everything together with soy sauce"
          ]
        }
      ],
      tips: [
        "Day-old rice works best for fried rice",
        "Adjust kimchi amount to taste",
        "Top with a fried egg for extra richness"
      ]
    }
  };

  // Find matching recipe category
  for (const [key, data] of Object.entries(recipeDatabase)) {
    if (input.includes(key)) {
      const recipe = data.recipes[0]; // Get first recipe
      return {
        content: `${getRandomResponse(key)} Here's a perfect recipe for you:`,
        recipe: {
          ...recipe,
          calories: Math.floor(Math.random() * 200) + 300
        },
        tips: data.tips
      };
    }
  }

  // Default response with random recipe
  const randomCategory = Object.keys(recipeDatabase)[Math.floor(Math.random() * Object.keys(recipeDatabase).length)];
  const randomData = recipeDatabase[randomCategory];
  
  return {
    content: "I love your enthusiasm! Let me suggest something delicious based on what's popular right now:",
    recipe: {
      ...randomData.recipes[0],
      calories: Math.floor(Math.random() * 200) + 300
    },
    tips: randomData.tips
  };
};

// Get random witty responses
const getRandomResponse = (category) => {
  const responses = {
    'eggs': [
      "Eggs are like the Swiss Army knife of cooking! 🥚",
      "Time to crack some culinary magic! 🪄",
      "Egg-cellent choice! Let's make something amazing! ✨"
    ],
    'healthy': [
      "Time to fuel your body like the temple it is! 💪",
      "Healthy never tasted so good! 🌱",
      "Your future self will thank you for this choice! 🙌"
    ],
    'quick': [
      "Speed cooking mode activated! ⚡",
      "Fast food, but make it fancy! 🚀",
      "Quick doesn't mean boring - let's prove it! 💨"
    ],
    'comfort': [
      "Ah, comfort food - the warm hug your soul needs! 🤗",
      "Time for some serious comfort vibes! ☁️",
      "Nothing beats a good comfort meal! 💕"
    ],
    'surprise': [
      "Plot twist time! 🎲",
      "Ready for a culinary adventure? 🗺️",
      "Let's shake things up in the kitchen! 🎪"
    ]
  };

  const categoryResponses = responses[category] || responses['surprise'];
  return categoryResponses[Math.floor(Math.random() * categoryResponses.length)];
};

// Daily recipe suggestions
export const getDailyRecipeSuggestions = async () => {
  const today = new Date();
  const dayOfWeek = today.getDay();
  
  // Different suggestions for each day of the week
  const dailyThemes = {
    0: 'comfort', // Sunday - comfort food
    1: 'healthy', // Monday - healthy start
    2: 'quick',   // Tuesday - quick meals
    3: 'surprise', // Wednesday - something different
    4: 'eggs',    // Thursday - egg dishes
    5: 'comfort', // Friday - comfort food
    6: 'healthy'  // Saturday - healthy options
  };

  const theme = dailyThemes[dayOfWeek];
  
  try {
    // Try to get themed recipes from API
    const recipes = await fetchRecipesFromAPI('', theme === 'healthy' ? 'Vegetarian' : '', '');
    return recipes.slice(0, 3);
  } catch (error) {
    // Fallback to local recipes
    return ENHANCED_RECIPES.slice(0, 3);
  }
};

export default {
  fetchRecipesFromAPI,
  getRecipeById,
  getRandomRecipe,
  searchByIngredients,
  getCategories,
  generateAIRecipe,
  getDailyRecipeSuggestions
};

