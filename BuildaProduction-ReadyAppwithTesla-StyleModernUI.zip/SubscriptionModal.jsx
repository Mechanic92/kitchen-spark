import React, { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Check, Crown, Zap, Star, X } from 'lucide-react';
import authService from '../services/authService';

const SubscriptionModal = ({ isOpen, onClose, currentTier = 'free' }) => {
  const [loading, setLoading] = useState(null);

  const plans = [
    {
      id: 'free',
      name: 'Free',
      price: '$0',
      period: 'forever',
      icon: Star,
      color: 'text-gray-600',
      bgColor: 'bg-gray-50',
      borderColor: 'border-gray-200',
      features: [
        'Save up to 10 recipes',
        'Basic AI chat responses',
        'Access to recipe database',
        'Standard recipe suggestions'
      ],
      limitations: [
        'Limited recipe saves',
        'No full recipe generation',
        'Basic features only'
      ]
    },
    {
      id: 'premium',
      name: 'Premium',
      price: '$9.99',
      period: 'per month',
      icon: Zap,
      color: 'text-orange-600',
      bgColor: 'bg-orange-50',
      borderColor: 'border-orange-200',
      popular: true,
      features: [
        'Unlimited recipe saves',
        'Full AI recipe generation',
        'Advanced recipe suggestions',
        'Personal recipe notes & ratings',
        'Priority customer support',
        'Export recipes to PDF'
      ],
      limitations: []
    },
    {
      id: 'pro',
      name: 'Pro',
      price: '$19.99',
      period: 'per month',
      icon: Crown,
      color: 'text-purple-600',
      bgColor: 'bg-purple-50',
      borderColor: 'border-purple-200',
      features: [
        'Everything in Premium',
        'Advanced meal planning',
        'Nutritional analysis',
        'Shopping list optimization',
        'Recipe video tutorials',
        'Custom dietary preferences',
        'Bulk recipe import/export',
        'API access for developers'
      ],
      limitations: []
    }
  ];

  const handleSubscribe = async (planId) => {
    if (!authService.isAuthenticated()) {
      alert('Please sign in first to subscribe');
      return;
    }

    if (planId === 'free') {
      alert('You are already on the free plan!');
      return;
    }

    setLoading(planId);
    
    try {
      // In a real implementation, this would create a Stripe checkout session
      const response = await fetch('http://localhost:5000/api/subscription/create-checkout-session', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${authService.getToken()}`
        },
        body: JSON.stringify({
          plan_id: planId
        })
      });

      const result = await response.json();
      
      if (result.success) {
        // Redirect to Stripe checkout
        window.location.href = result.checkout_url;
      } else {
        alert('Failed to create checkout session: ' + result.error);
      }
    } catch (error) {
      console.error('Error creating checkout session:', error);
      alert('Failed to start subscription process');
    } finally {
      setLoading(null);
    }
  };

  const handleManageSubscription = async () => {
    if (!authService.isAuthenticated()) {
      alert('Please sign in first');
      return;
    }

    setLoading('manage');
    
    try {
      const response = await fetch('http://localhost:5000/api/subscription/create-portal-session', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${authService.getToken()}`
        }
      });

      const result = await response.json();
      
      if (result.success) {
        // Redirect to Stripe customer portal
        window.location.href = result.portal_url;
      } else {
        alert('Failed to access subscription management: ' + result.error);
      }
    } catch (error) {
      console.error('Error accessing subscription management:', error);
      alert('Failed to access subscription management');
    } finally {
      setLoading(null);
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-6xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="text-2xl font-bold text-center">
            Choose Your Kitchen Spark Plan
          </DialogTitle>
          <p className="text-center text-gray-600 mt-2">
            Unlock the full potential of your culinary journey
          </p>
        </DialogHeader>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mt-6">
          {plans.map((plan) => {
            const Icon = plan.icon;
            const isCurrentPlan = currentTier === plan.id;
            const isPopular = plan.popular;
            
            return (
              <Card 
                key={plan.id} 
                className={`relative ${plan.borderColor} ${
                  isPopular ? 'ring-2 ring-orange-500 ring-opacity-50' : ''
                } ${isCurrentPlan ? 'bg-blue-50 border-blue-300' : ''}`}
              >
                {isPopular && (
                  <div className="absolute -top-3 left-1/2 transform -translate-x-1/2">
                    <Badge className="bg-orange-500 text-white px-3 py-1">
                      Most Popular
                    </Badge>
                  </div>
                )}
                
                {isCurrentPlan && (
                  <div className="absolute -top-3 right-4">
                    <Badge className="bg-blue-500 text-white px-3 py-1">
                      Current Plan
                    </Badge>
                  </div>
                )}

                <CardHeader className={`text-center ${plan.bgColor} rounded-t-lg`}>
                  <div className="flex justify-center mb-2">
                    <Icon className={`h-8 w-8 ${plan.color}`} />
                  </div>
                  <CardTitle className="text-xl font-bold">{plan.name}</CardTitle>
                  <div className="mt-2">
                    <span className="text-3xl font-bold">{plan.price}</span>
                    <span className="text-gray-600 ml-1">/{plan.period}</span>
                  </div>
                </CardHeader>

                <CardContent className="p-6">
                  <div className="space-y-4">
                    {/* Features */}
                    <div>
                      <h4 className="font-semibold text-sm text-gray-900 mb-2">Features:</h4>
                      <ul className="space-y-2">
                        {plan.features.map((feature, index) => (
                          <li key={index} className="flex items-start gap-2">
                            <Check className="h-4 w-4 text-green-500 mt-0.5 flex-shrink-0" />
                            <span className="text-sm text-gray-700">{feature}</span>
                          </li>
                        ))}
                      </ul>
                    </div>

                    {/* Limitations */}
                    {plan.limitations.length > 0 && (
                      <div>
                        <h4 className="font-semibold text-sm text-gray-900 mb-2">Limitations:</h4>
                        <ul className="space-y-2">
                          {plan.limitations.map((limitation, index) => (
                            <li key={index} className="flex items-start gap-2">
                              <X className="h-4 w-4 text-red-500 mt-0.5 flex-shrink-0" />
                              <span className="text-sm text-gray-500">{limitation}</span>
                            </li>
                          ))}
                        </ul>
                      </div>
                    )}

                    {/* Action Button */}
                    <div className="pt-4">
                      {isCurrentPlan ? (
                        currentTier !== 'free' ? (
                          <Button
                            variant="outline"
                            className="w-full"
                            onClick={handleManageSubscription}
                            disabled={loading === 'manage'}
                          >
                            {loading === 'manage' ? 'Loading...' : 'Manage Subscription'}
                          </Button>
                        ) : (
                          <Button variant="outline" className="w-full" disabled>
                            Current Plan
                          </Button>
                        )
                      ) : (
                        <Button
                          className={`w-full ${
                            plan.id === 'premium'
                              ? 'bg-orange-500 hover:bg-orange-600'
                              : plan.id === 'pro'
                              ? 'bg-purple-500 hover:bg-purple-600'
                              : 'bg-gray-500 hover:bg-gray-600'
                          }`}
                          onClick={() => handleSubscribe(plan.id)}
                          disabled={loading === plan.id}
                        >
                          {loading === plan.id ? (
                            <div className="flex items-center gap-2">
                              <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
                              Processing...
                            </div>
                          ) : plan.id === 'free' ? (
                            'Get Started'
                          ) : (
                            `Upgrade to ${plan.name}`
                          )}
                        </Button>
                      )}
                    </div>
                  </div>
                </CardContent>
              </Card>
            );
          })}
        </div>

        {/* Additional Info */}
        <div className="mt-8 text-center text-sm text-gray-600">
          <p>All plans include a 7-day free trial. Cancel anytime.</p>
          <p className="mt-1">Secure payments powered by Stripe.</p>
        </div>
      </DialogContent>
    </Dialog>
  );
};

export default SubscriptionModal;

