# Kitchen Spark Backend Architecture & Database Schema

## Executive Summary

This document outlines the comprehensive backend architecture for Kitchen Spark, a modern cooking application that will be enhanced with user authentication, Stripe monetization, and personalized recipe management features. The architecture follows industry best practices for scalable web applications, implementing a tiered subscription model that provides value to users while generating sustainable revenue.

## System Architecture Overview

The Kitchen Spark backend will be built using Flask, a lightweight and flexible Python web framework that provides excellent support for rapid development and deployment. The architecture follows a RESTful API design pattern, ensuring clean separation between the frontend React application and backend services.

### Core Components

The system consists of several interconnected components that work together to provide a seamless user experience. The Flask application server handles all HTTP requests and implements business logic, while SQLite serves as the primary database for development and testing phases. The authentication system uses JWT (JSON Web Tokens) for secure, stateless user sessions, and Stripe integration provides robust payment processing capabilities.

The application implements a microservices-inspired architecture within a monolithic Flask application, with clear separation of concerns between different functional areas. This approach provides the benefits of modular design while maintaining the simplicity of a single deployable unit.

## Database Schema Design

### User Management Tables

The user management system forms the foundation of the application's personalization and monetization features. The primary `users` table stores essential user information and account status.

```sql
CREATE TABLE users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    email VARCHAR(255) UNIQUE NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    first_name VARCHAR(100),
    last_name VARCHAR(100),
    subscription_tier VARCHAR(20) DEFAULT 'free',
    stripe_customer_id VARCHAR(100),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    last_login TIMESTAMP,
    is_active BOOLEAN DEFAULT TRUE,
    email_verified BOOLEAN DEFAULT FALSE
);
```

The subscription system supports three distinct tiers: 'free', 'premium', and 'pro', each offering progressively more features and capabilities. The `stripe_customer_id` field links users to their Stripe customer records, enabling seamless payment processing and subscription management.

### Recipe Management Tables

The recipe management system allows users to save, organize, and access their favorite recipes. The `saved_recipes` table creates a many-to-many relationship between users and recipes.

```sql
CREATE TABLE saved_recipes (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL,
    recipe_id VARCHAR(100) NOT NULL,
    recipe_title VARCHAR(255),
    recipe_image_url TEXT,
    recipe_source VARCHAR(50) DEFAULT 'themealdb',
    saved_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    notes TEXT,
    rating INTEGER CHECK (rating >= 1 AND rating <= 5),
    FOREIGN KEY (user_id) REFERENCES users (id) ON DELETE CASCADE,
    UNIQUE(user_id, recipe_id, recipe_source)
);
```

This design accommodates recipes from multiple sources, including TheMealDB API and potentially user-generated content in future iterations. The `notes` field allows users to add personal cooking notes, while the `rating` system enables personalized recipe recommendations.

### Subscription and Payment Tables

The subscription management system tracks user payment history and subscription status through dedicated tables that integrate with Stripe's webhook system.

```sql
CREATE TABLE subscriptions (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL,
    stripe_subscription_id VARCHAR(100) UNIQUE,
    tier VARCHAR(20) NOT NULL,
    status VARCHAR(20) NOT NULL,
    current_period_start TIMESTAMP,
    current_period_end TIMESTAMP,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users (id) ON DELETE CASCADE
);

CREATE TABLE payment_history (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL,
    stripe_payment_intent_id VARCHAR(100),
    amount INTEGER NOT NULL,
    currency VARCHAR(3) DEFAULT 'usd',
    status VARCHAR(20) NOT NULL,
    description TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users (id) ON DELETE CASCADE
);
```

### User Activity and Analytics Tables

To support personalized recommendations and usage analytics, the system includes tables for tracking user interactions and preferences.

```sql
CREATE TABLE user_activity (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL,
    activity_type VARCHAR(50) NOT NULL,
    recipe_id VARCHAR(100),
    metadata JSON,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users (id) ON DELETE CASCADE
);

CREATE TABLE user_preferences (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL,
    dietary_restrictions JSON,
    favorite_cuisines JSON,
    cooking_skill_level VARCHAR(20),
    preferred_meal_types JSON,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users (id) ON DELETE CASCADE
);
```

## API Endpoint Design

### Authentication Endpoints

The authentication system provides secure user registration, login, and session management through JWT tokens.

**POST /api/auth/register**
- Creates new user accounts with email verification
- Validates email uniqueness and password strength
- Returns JWT token for immediate authentication

**POST /api/auth/login**
- Authenticates users with email and password
- Updates last_login timestamp
- Returns JWT token and user profile information

**POST /api/auth/logout**
- Invalidates JWT tokens (client-side token removal)
- Updates user activity logs

**GET /api/auth/profile**
- Returns current user profile information
- Requires valid JWT authentication

### Recipe Management Endpoints

The recipe management API provides comprehensive functionality for discovering, saving, and organizing recipes.

**GET /api/recipes/discover**
- Returns paginated recipe listings from TheMealDB
- Supports filtering by cuisine, difficulty, and dietary restrictions
- Includes personalized recommendations for authenticated users

**POST /api/recipes/save**
- Saves recipes to user's personal collection
- Requires premium or pro subscription for unlimited saves
- Free tier limited to 10 saved recipes

**GET /api/recipes/saved**
- Returns user's saved recipe collection
- Supports search and filtering within saved recipes
- Includes user notes and ratings

**DELETE /api/recipes/saved/{recipe_id}**
- Removes recipes from user's saved collection
- Soft delete maintains activity history

### Subscription Management Endpoints

The subscription system integrates with Stripe to provide seamless payment processing and tier management.

**GET /api/subscription/tiers**
- Returns available subscription tiers and pricing
- Includes feature comparison information

**POST /api/subscription/create-checkout**
- Creates Stripe checkout session for subscription upgrade
- Handles both new subscriptions and tier changes

**POST /api/subscription/webhook**
- Processes Stripe webhook events
- Updates subscription status and user tiers
- Handles payment failures and cancellations

## Subscription Tier Strategy

### Free Tier Features

The free tier provides essential functionality to attract users while demonstrating the application's value proposition. Free users can access basic recipe discovery, save up to 10 recipes, and use limited AI chat functionality (5 queries per day). This tier serves as an effective funnel for converting users to paid subscriptions.

### Premium Tier ($9.99/month)

The premium tier targets serious home cooks who want enhanced functionality without professional-level features. Premium users enjoy unlimited recipe saves, advanced search and filtering options, unlimited AI chat interactions, meal planning tools, and shopping list generation. This tier represents the primary revenue driver for the application.

### Pro Tier ($19.99/month)

The pro tier caters to culinary enthusiasts, food bloggers, and professional cooks who require advanced features. Pro users receive all premium features plus recipe creation and sharing capabilities, advanced nutritional analysis, batch cooking calculators, integration with smart kitchen devices, and priority customer support.

## Security Implementation

### Authentication Security

The authentication system implements industry-standard security practices to protect user data and prevent unauthorized access. Password hashing uses bcrypt with a minimum of 12 rounds, ensuring computational difficulty for potential attackers. JWT tokens include expiration times and are signed with strong secrets stored as environment variables.

### Data Protection

All sensitive user data is encrypted at rest using SQLite's built-in encryption capabilities in production environments. API endpoints implement rate limiting to prevent abuse, and input validation protects against injection attacks. CORS policies restrict cross-origin requests to authorized domains.

### Payment Security

Stripe integration follows PCI DSS compliance requirements, with sensitive payment information never stored on application servers. All payment processing occurs through Stripe's secure infrastructure, with only necessary metadata stored locally for subscription management.

## Performance Optimization

### Database Optimization

Database performance is optimized through strategic indexing on frequently queried columns, including user email addresses, recipe IDs, and subscription status fields. Query optimization focuses on minimizing N+1 problems through eager loading and efficient join operations.

### Caching Strategy

The application implements multi-level caching to reduce database load and improve response times. Redis caching stores frequently accessed recipe data from TheMealDB API, while application-level caching maintains user session information and subscription status.

### API Rate Limiting

Rate limiting protects the application from abuse while ensuring fair usage across all users. Free tier users face stricter limits to encourage subscription upgrades, while premium and pro users enjoy higher rate limits commensurate with their subscription level.

## Deployment Architecture

### Development Environment

The development environment uses SQLite for simplicity and rapid iteration, with Flask's built-in development server providing hot reloading capabilities. Environment variables manage configuration differences between development and production environments.

### Production Environment

Production deployment utilizes containerized Flask applications with Gunicorn WSGI servers for improved performance and reliability. PostgreSQL replaces SQLite for enhanced concurrent access and data integrity. Load balancing and auto-scaling ensure consistent performance under varying traffic loads.

### Monitoring and Logging

Comprehensive logging captures application events, user activities, and system performance metrics. Error tracking and alerting systems provide immediate notification of critical issues, while analytics dashboards offer insights into user behavior and subscription conversion rates.

## Integration Points

### TheMealDB API Integration

The existing integration with TheMealDB API continues to provide recipe data, enhanced with caching and error handling for improved reliability. API responses are normalized and cached to reduce external dependencies and improve response times.

### Stripe Integration

Stripe integration handles all payment processing, subscription management, and webhook processing. The system maintains synchronization between Stripe subscription status and local user records through automated webhook handlers.

### Email Service Integration

Email services support user verification, password resets, and subscription notifications. Integration with services like SendGrid or AWS SES provides reliable email delivery with tracking and analytics capabilities.

This comprehensive architecture provides a solid foundation for Kitchen Spark's evolution into a full-featured, monetized cooking application while maintaining the flexibility to adapt to changing requirements and user needs.

