const API_BASE_URL = '/api';

class AuthService {
  constructor() {
    this.token = localStorage.getItem('kitchen_spark_token');
    this.user = JSON.parse(localStorage.getItem('kitchen_spark_user') || 'null');
  }

  // Get auth headers for API requests
  getAuthHeaders() {
    return {
      'Content-Type': 'application/json',
      ...(this.token && { 'Authorization': `Bearer ${this.token}` })
    };
  }

  // Register new user
  async register(userData) {
    try {
      const response = await fetch(`${API_BASE_URL}/auth/register`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify(userData)
      });

      const data = await response.json();

      if (!response.ok) {
        throw new Error(data.error || 'Registration failed');
      }

      // Store token and user data
      this.token = data.access_token;
      this.user = data.user;
      localStorage.setItem('kitchen_spark_token', this.token);
      localStorage.setItem('kitchen_spark_user', JSON.stringify(this.user));

      return { success: true, user: this.user };
    } catch (error) {
      console.error('Registration error:', error);
      return { success: false, error: error.message };
    }
  }

  // Login user
  async login(email, password) {
    try {
      const response = await fetch(`${API_BASE_URL}/auth/login`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({ email, password })
      });

      const data = await response.json();

      if (!response.ok) {
        throw new Error(data.error || 'Login failed');
      }

      // Store token and user data
      this.token = data.access_token;
      this.user = data.user;
      localStorage.setItem('kitchen_spark_token', this.token);
      localStorage.setItem('kitchen_spark_user', JSON.stringify(this.user));

      return { success: true, user: this.user };
    } catch (error) {
      console.error('Login error:', error);
      return { success: false, error: error.message };
    }
  }

  // Logout user
  async logout() {
    try {
      if (this.token) {
        await fetch(`${API_BASE_URL}/auth/logout`, {
          method: 'POST',
          headers: this.getAuthHeaders()
        });
      }
    } catch (error) {
      console.error('Logout error:', error);
    } finally {
      // Clear local storage regardless of API call success
      this.token = null;
      this.user = null;
      localStorage.removeItem('kitchen_spark_token');
      localStorage.removeItem('kitchen_spark_user');
    }
  }

  // Get current user profile
  async getProfile() {
    try {
      if (!this.token) {
        throw new Error('No authentication token');
      }

      const response = await fetch(`${API_BASE_URL}/auth/profile`, {
        method: 'GET',
        headers: this.getAuthHeaders()
      });

      const data = await response.json();

      if (!response.ok) {
        throw new Error(data.error || 'Failed to get profile');
      }

      this.user = data.user;
      localStorage.setItem('kitchen_spark_user', JSON.stringify(this.user));

      return { success: true, user: this.user };
    } catch (error) {
      console.error('Get profile error:', error);
      return { success: false, error: error.message };
    }
  }

  // Update user profile
  async updateProfile(profileData) {
    try {
      if (!this.token) {
        throw new Error('No authentication token');
      }

      const response = await fetch(`${API_BASE_URL}/auth/profile`, {
        method: 'PUT',
        headers: this.getAuthHeaders(),
        body: JSON.stringify(profileData)
      });

      const data = await response.json();

      if (!response.ok) {
        throw new Error(data.error || 'Failed to update profile');
      }

      this.user = data.user;
      localStorage.setItem('kitchen_spark_user', JSON.stringify(this.user));

      return { success: true, user: this.user };
    } catch (error) {
      console.error('Update profile error:', error);
      return { success: false, error: error.message };
    }
  }

  // Change password
  async changePassword(currentPassword, newPassword) {
    try {
      if (!this.token) {
        throw new Error('No authentication token');
      }

      const response = await fetch(`${API_BASE_URL}/auth/change-password`, {
        method: 'POST',
        headers: this.getAuthHeaders(),
        body: JSON.stringify({
          current_password: currentPassword,
          new_password: newPassword
        })
      });

      const data = await response.json();

      if (!response.ok) {
        throw new Error(data.error || 'Failed to change password');
      }

      return { success: true, message: data.message };
    } catch (error) {
      console.error('Change password error:', error);
      return { success: false, error: error.message };
    }
  }

  // Verify token validity
  async verifyToken() {
    try {
      if (!this.token) {
        return { success: false, error: 'No token' };
      }

      const response = await fetch(`${API_BASE_URL}/auth/verify-token`, {
        method: 'POST',
        headers: this.getAuthHeaders()
      });

      const data = await response.json();

      if (!response.ok) {
        // Token is invalid, clear it
        this.logout();
        return { success: false, error: 'Invalid token' };
      }

      this.user = data.user;
      localStorage.setItem('kitchen_spark_user', JSON.stringify(this.user));

      return { success: true, user: this.user };
    } catch (error) {
      console.error('Token verification error:', error);
      this.logout();
      return { success: false, error: error.message };
    }
  }

  // Check if user is authenticated
  isAuthenticated() {
    return !!this.token && !!this.user;
  }

  // Get current user
  getCurrentUser() {
    return this.user;
  }

  // Get user subscription tier
  getSubscriptionTier() {
    return this.user?.subscription_tier || 'free';
  }

  // Check if user has premium features
  hasPremiumFeatures() {
    const tier = this.getSubscriptionTier();
    return tier === 'premium' || tier === 'pro';
  }

  // Check if user has pro features
  hasProFeatures() {
    return this.getSubscriptionTier() === 'pro';
  }
}

// Create singleton instance
const authService = new AuthService();

export default authService;

