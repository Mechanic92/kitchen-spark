import { useState, useEffect } from 'react'
import { RecipeCard } from './RecipeCard'
import { RecipeDetailModal } from './RecipeDetailModal'
import { fetchRecipesFromAPI, getDailyRecipeSuggestions, getRecipeById } from '../services/recipeService'
import savedRecipesService from '../services/savedRecipesService'
import authService from '../services/authService'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { RefreshCw, Filter } from 'lucide-react'

export function RecipeGrid() {
  const [recipes, setRecipes] = useState([])
  const [savedRecipeIds, setSavedRecipeIds] = useState(new Set())
  const [selectedRecipe, setSelectedRecipe] = useState(null)
  const [isModalOpen, setIsModalOpen] = useState(false)
  const [loading, setLoading] = useState(true)
  const [dailySuggestions, setDailySuggestions] = useState([])
  const [savingRecipe, setSavingRecipe] = useState(null)

  useEffect(() => {
    loadRecipes()
    loadDailySuggestions()
    if (authService.isAuthenticated()) {
      loadSavedRecipeIds()
    }
  }, [])

  const loadRecipes = async () => {
    setLoading(true)
    try {
      const result = await savedRecipesService.discoverRecipes()
      if (result.success) {
        setRecipes(result.recipes.map(recipe => ({
          ...recipe,
          saved: savedRecipeIds.has(recipe.id)
        })))
      }
    } catch (error) {
      console.error('Error loading recipes:', error)
    } finally {
      setLoading(false)
    }
  }

  const loadSavedRecipeIds = async () => {
    try {
      const result = await savedRecipesService.getSavedRecipes({ per_page: 1000 })
      if (result.success) {
        const savedIds = new Set(result.recipes.map(recipe => recipe.recipe_id))
        setSavedRecipeIds(savedIds)
      }
    } catch (error) {
      console.error('Error loading saved recipe IDs:', error)
    }
  }

  const loadDailySuggestions = async () => {
    try {
      const suggestions = await getDailyRecipeSuggestions()
      setDailySuggestions(suggestions)
    } catch (error) {
      console.error('Error loading daily suggestions:', error)
    }
  }

  const handleSaveRecipe = async (recipe) => {
    if (!authService.isAuthenticated()) {
      alert('Please sign in to save recipes')
      return
    }

    setSavingRecipe(recipe.id)
    
    try {
      const isCurrentlySaved = savedRecipeIds.has(recipe.id)
      
      if (isCurrentlySaved) {
        // Find the saved recipe to get its database ID
        const savedRecipesResult = await savedRecipesService.getSavedRecipes({ per_page: 1000 })
        if (savedRecipesResult.success) {
          const savedRecipe = savedRecipesResult.recipes.find(r => r.recipe_id === recipe.id)
          if (savedRecipe) {
            const result = await savedRecipesService.removeSavedRecipe(savedRecipe.id)
            if (result.success) {
              setSavedRecipeIds(prev => {
                const newSet = new Set(prev)
                newSet.delete(recipe.id)
                return newSet
              })
              // Update recipe in list
              setRecipes(prev => prev.map(r => 
                r.id === recipe.id ? { ...r, saved: false } : r
              ))
            } else {
              alert('Failed to remove recipe: ' + result.error)
            }
          }
        }
      } else {
        const result = await savedRecipesService.saveRecipe({
          recipe_id: recipe.id,
          recipe_title: recipe.title,
          recipe_image_url: recipe.image,
          recipe_source: recipe.source || 'themealdb'
        })
        
        if (result.success) {
          setSavedRecipeIds(prev => new Set([...prev, recipe.id]))
          // Update recipe in list
          setRecipes(prev => prev.map(r => 
            r.id === recipe.id ? { ...r, saved: true } : r
          ))
        } else {
          if (result.error.includes('limit reached')) {
            alert('You\'ve reached your recipe save limit. Upgrade to Premium for unlimited saves!')
          } else {
            alert('Failed to save recipe: ' + result.error)
          }
        }
      }
    } catch (error) {
      console.error('Error toggling recipe save:', error)
      alert('Failed to save/remove recipe')
    } finally {
      setSavingRecipe(null)
    }
  }

  const handleViewRecipe = async (recipeId) => {
    try {
      const recipe = await getRecipeById(recipeId)
      if (recipe) {
        setSelectedRecipe(recipe)
        setIsModalOpen(true)
      }
    } catch (error) {
      console.error('Error loading recipe details:', error)
    }
  }

  const closeRecipeDetail = () => {
    setIsModalOpen(false)
    setSelectedRecipe(null)
  }

  const refreshRecipes = () => {
    loadRecipes()
    if (authService.isAuthenticated()) {
      loadSavedRecipeIds()
    }
  }

  if (loading) {
    return (
      <div className="space-y-6">
        <div className="text-center py-12">
          <div className="animate-spin rounded-full h-16 w-16 border-b-2 border-blue-600 mx-auto"></div>
          <p className="mt-4 text-gray-600 dark:text-gray-300 text-lg">Loading delicious recipes...</p>
          <p className="text-sm text-gray-500 dark:text-gray-400 mt-2">Fetching fresh content from our recipe database</p>
        </div>
      </div>
    )
  }

  return (
    <div className="space-y-8">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-gray-900 dark:text-white">Discover Recipes</h1>
          <p className="text-gray-600 dark:text-gray-300 mt-1">Find your next culinary adventure</p>
        </div>
        <div className="flex gap-2">
          <Button variant="outline" size="sm">
            <Filter className="h-4 w-4 mr-2" />
            Filter
          </Button>
          <Button variant="outline" size="sm" onClick={refreshRecipes}>
            <RefreshCw className="h-4 w-4 mr-2" />
            Refresh
          </Button>
        </div>
      </div>

      {/* Daily Suggestions */}
      {dailySuggestions.length > 0 && (
        <div className="bg-gradient-to-r from-yellow-50 to-orange-50 dark:from-yellow-900/20 dark:to-orange-900/20 rounded-2xl p-6 border border-yellow-200 dark:border-yellow-800">
          <div className="flex items-center gap-2 mb-4">
            <span className="text-2xl">🌟</span>
            <h2 className="text-xl font-semibold text-gray-900 dark:text-white">
              Today's Curated Picks
            </h2>
            <Badge className="bg-yellow-500 text-yellow-900">
              Fresh Daily
            </Badge>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {dailySuggestions.map((recipe) => (
              <div 
                key={`daily-${recipe.id}`} 
                className="bg-white dark:bg-gray-800 rounded-lg p-4 cursor-pointer hover:shadow-lg transition-all duration-200 border border-yellow-200 dark:border-yellow-700"
                onClick={() => handleViewRecipe(recipe.id)}
              >
                <img 
                  src={recipe.image} 
                  alt={recipe.title}
                  className="w-full h-24 object-cover rounded-lg mb-3"
                />
                <h3 className="font-medium text-sm text-gray-900 dark:text-white line-clamp-1 mb-1">
                  {recipe.title}
                </h3>
                <p className="text-xs text-gray-600 dark:text-gray-300 line-clamp-2">
                  {recipe.description}
                </p>
                <div className="flex items-center gap-2 mt-2 text-xs text-gray-500">
                  <span>{recipe.cookTime}</span>
                  <span>•</span>
                  <span>{recipe.calories} cal</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Main Recipe Grid */}
      <div>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {recipes.map((recipe) => (
            <RecipeCard
              key={recipe.id}
              recipe={recipe}
              onSave={handleSaveRecipe}
              onView={handleViewRecipe}
              isSaved={savedRecipeIds.has(recipe.id)}
              isSaving={savingRecipe === recipe.id}
            />
          ))}
        </div>

        {recipes.length === 0 && !loading && (
          <div className="text-center py-12">
            <div className="text-6xl mb-4">🍳</div>
            <h3 className="text-xl font-semibold text-gray-900 dark:text-white mb-2">
              No recipes found
            </h3>
            <p className="text-gray-600 dark:text-gray-300 mb-4">
              Try refreshing or check your connection
            </p>
            <Button onClick={refreshRecipes}>
              <RefreshCw className="h-4 w-4 mr-2" />
              Try Again
            </Button>
          </div>
        )}
      </div>

      {/* Recipe Detail Modal */}
      <RecipeDetailModal
        recipe={selectedRecipe}
        isOpen={isModalOpen}
        onClose={closeRecipeDetail}
        onSave={handleSaveRecipe}
        isSaved={selectedRecipe ? savedRecipeIds.has(selectedRecipe.id) : false}
      />
    </div>
  )
}

