from flask import Flask, jsonify, request
import json

app = Flask(__name__)

@app.route("/products", methods=["GET"])
def get_products():
    with open("/home/ubuntu/placeholder_api/data/sample_products.json", "r") as f:
        products = json.load(f)

    search_term = request.args.get("q")
    supermarket = request.args.get("supermarket")

    if search_term:
        products = [p for p in products if search_term.lower() in p["name"].lower()]

    if supermarket:
        products = [p for p in products if p["supermarket"].lower() == supermarket.lower()]

    return jsonify(products)

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000)

