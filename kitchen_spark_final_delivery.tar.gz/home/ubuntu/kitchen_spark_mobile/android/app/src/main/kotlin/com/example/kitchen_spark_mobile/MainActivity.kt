package com.example.kitchen_spark_mobile

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
